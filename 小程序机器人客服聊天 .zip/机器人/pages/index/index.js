//index.js
Page({
  data: {
    // 联系人列表
    usersList: [
      { name: "老五", src: "http://tu.maomaogougou.cn/picture/2016/09/37043d8c1aeaa0d768998a689a9a6fe1.jpg", time: "12:00" },
      { name: "老五", src: "http://tu.maomaogougou.cn/picture/2016/09/37043d8c1aeaa0d768998a689a9a6fe1.jpg", time: "12:00" },



    ]
  },
  // 跳转聊天页面
  btn_sub: function () {
    wx.navigateTo({ url: "../tel/tel" })
  },
  onLoad:function() {
wx.setStorageSync("key",1);
    wx.getStorageInfo({
      success: function (res) {
        console.log(res.keys)
        console.log(res.currentSize)
        console.log(res.limitSize)
      }
    })
  },
})
