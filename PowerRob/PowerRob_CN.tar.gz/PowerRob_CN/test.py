# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports

import random
import time
from lxml import etree
from datetime import datetime, timedelta


import  os


# local imports

html_str = '''<!DOCTYPE html>
<!--STATUS OK-->
<html>



<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<meta name="referrer" content="always" />
<meta name="description" content="变电站是指电力系统中对电压和电流进行变换，接受电能及分配电能的场所。在发电厂内的变电站是升压变电站，其作用是将发电机发出的电能升压后馈送到高压电网中。...">
<title>变电站_百度百科</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link rel="icon" sizes="any" mask href="//www.baidu.com/img/baidu.svg">

<meta name="keywords" content="变电站 变电站分类 变电站设备 变电站布设要求 变电站巡检 变电站技术档案 变电站发展">
<meta name="image" content="https://bkssl.bdimg.com/cms/static/baike.png">
<script type="text/javascript">
  // 配置 PD 监控。
  window.alogObjectConfig = {
    product: '103',
    page: '103_1',
    speed: {
      sample: '0.008'
    },
    monkey: {
      sample: '1',
      hid: '1533'
    },
    exception: { 
      sample: '0.004'
    },
    feature: {
      sample: '0.004'
    },
    csp: {
      sample: '0.008',
      'default-src': [
        {match: '*.baidu.com,*.bdimg.com,localhost', target: 'Accept'},
        {match: '*', target: 'Accept,Warn'}
      ]
    }
  };

  void function(a,b,c,d,e,f,g){a.alogObjectName=e,a[e]=a[e]||function(){(a[e].q=a[e].q||[]).push(arguments)},a[e].l=a[e].l||+new Date,d="https:"===a.location.protocol?"https://fex.bdstatic.com"+d:"http://fex.bdstatic.com"+d;var h=!0;if(a.alogObjectConfig&&a.alogObjectConfig.sample){var i=Math.random();a.alogObjectConfig.rand=i,i>a.alogObjectConfig.sample&&(h=!1)}h&&(f=b.createElement(c),f.async=!0,f.src=d+"?v="+~(new Date/864e5)+~(new Date/864e5),g=b.getElementsByTagName(c)[0],g.parentNode.insertBefore(f,g))}(window,document,"script","/hunter/alog/alog.min.js","alog"),void function(){function a(){}window.PDC={mark:function(a,b){alog("speed.set",a,b||+new Date),alog.fire&&alog.fire("mark")},init:function(a){alog("speed.set","options",a)},view_start:a,tti:a,page_ready:a}}();
  void function(n){var o=!1;n.onerror=function(n,e,t,c){var i=!0;return!e&&/^script error/i.test(n)&&(o?i=!1:o=!0),i&&alog("exception.send","exception",{msg:n,js:e,ln:t,col:c}),!1},alog("exception.on","catch",function(n){alog("exception.send","exception",{msg:n.msg,js:n.path,ln:n.ln,method:n.method,flag:"catch"})})}(window);
</script>
<meta name="csrf-token" content="">
<meta itemprop="dateUpdate" content="2019-02-27 15:52:27" />

<!--[if lte IE 9]>
<script>
    (function() {
      var e = "abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,time,video".split(","),
        i = e.length;
      while (i--) {
        document.createElement(e[i]);
      }
    })();
  </script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/pkg/wiki-lemma_a152d97.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-common/pkg/wiki-common-base_66a9374.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-common/widget/component/userbar-n/userbar-n_2890903.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-common/widget/lib/larkplayer/larkplayer_981c735.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-common/widget/lib/webuploader/webuploader_08d9db4.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/pkg/wiki-lemma-module_6b75841.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/pageBackground/pageBackground_d077e01.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/announcement/announcement_cba33f4.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/label/label_ca156c6.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/newSideShare/sideShare_9c411cd.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/video/pageMask/pageMask_ff9a193.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/mainContent_98e3702.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/lemmaRelation/lemmaRelation_ac86a59.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/professional/professional_054b270.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/zhixin/zhixin_3b0d7a5.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/sideAuth/sideAuth_c13d91a.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/searchHeader/toolButtons-n/toolButtons-n_8b4919b.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/searchHeader/toolButtons-n/userInfo-n_7e90184.css"/><link rel="stylesheet" type="text/css" href="https://bkssl.bdimg.com/static/wiki-lemma/widget/tools/searchHeader/searchHeader-n_f9a6e5b.css"/>    
</head>

<script type="text/javascript">
    alog('speed.set', 'ht', +new Date);
</script>
<script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?55b574651fcae74b0a9f1cf9c8d7c93a";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
    </script>

<body class="wiki-lemma normal">


<div class="header-wrapper pc-header-new">
<div class="topbar cmn-clearfix">
<ul class="wgt-userbar wgt-userbar-n" id="j-wgt-userbar">
<li>
<a href="http://www.baidu.com/">百度首页</a>
</li>
</ul>
<div class="separator"></div>
<div class="wiki-common-headTabBar">
<a href="https://www.baidu.com/" nslog="normal" nslog-type="10600112" data-href="https://www.baidu.com/s?ie=utf-8&fr=bks0000&wd=">网页</a>
<a href="http://news.baidu.com/" nslog="normal" nslog-type="10600112" data-href="http://news.baidu.com/ns?tn=news&cl=2&rn=20&ct=1&fr=bks0000&ie=utf-8&word=">新闻</a>
<a href="https://tieba.baidu.com/" nslog="normal" nslog-type="10600112" data-href="https://tieba.baidu.com/f?ie=utf-8&fr=bks0000&kw=">贴吧</a>
<a href="https://zhidao.baidu.com/" nslog="normal" nslog-type="10600112" data-href="https://zhidao.baidu.com/search?pn=0&&rn=10&lm=0&fr=bks0000&word=">知道</a>
<a href="http://music.baidu.com/" nslog="normal" nslog-type="10600112" data-href="http://music.baidu.com/search?f=ms&ct=134217728&ie=utf-8&rn=&lm=-1&pn=30&fr=bks0000&key=">音乐</a>
<a href="http://image.baidu.com/" nslog="normal" nslog-type="10600112" data-href="http://image.baidu.com/search/index?tn=baiduimage&ct=201326592&lm=-1&cl=2&nc=1&ie=utf-8&word=">图片</a>
<a href="http://v.baidu.com/" nslog="normal" nslog-type="10600112" data-href="http://v.baidu.com/v?ct=301989888&rn=20&pn=0&db=0&s=22&ie=utf-8&fr=bks0000&word=">视频</a>
<a href="http://map.baidu.com/" nslog="normal" nslog-type="10600112" data-href="http://map.baidu.com/m?ie=utf-8&fr=bks0000&word=">地图</a>
<a href="https://wenku.baidu.com/" nslog="normal" nslog-type="10600112" data-href="https://wenku.baidu.com/search?lm=0&od=0&ie=utf-8&fr=bks0000&word=">文库</a>
<b class="baike">百科</b>
</div>
</div>
<div class="header">
<div class="layout">
<div class="wgt-searchbar wgt-searchbar-new wgt-searchbar-main cmn-clearfix wgt-searchbar-large">
<div class="logo-container">
<a class="logo cmn-inline-block" title="到百科首页" href="/">
<span class="cmn-baike-logo">
<em class="cmn-icon cmn-icons cmn-icons_logo-bai"></em>
<em class="cmn-icon cmn-icons cmn-icons_logo-du"></em>
<em class="cmn-icon cmn-icons cmn-icons_logo-baike"></em>
</span>
</a>
</div>
<div class="search">
<div class="form">
<form id="searchForm" action="/search/word" method="GET" target="_self">
<input id="query" nslog="normal" nslog-type="10080011" name="word" type="text" autocomplete="off" autocorrect="off" value="变电站" /><button id="search" nslog="normal" nslog-type="10080008" type="button">进入词条</button><button id="searchLemma" nslog="normal" nslog-type="10080009" type="button">全站搜索</button><a class="help" href="/help" nslog="normal" nslog-type="10080010" target="_blank">帮助</a>
</form>
<form id="searchLemmaForm" action="/search" method="GET" target="_self">
<input id="searchLemmaQuery" name="word" type="hidden" />
<input name="pn" type="hidden" value="0" />
<input name="rn" type="hidden" value="0" />
<input name="enc" type="hidden" value="utf8" />
</form>
<ul id="suggestion" class="suggestion">
<div class="sug"></div>
<li class="extra">
<span id="clear" style="margin-right:8px;">清除历史记录</span><span id="close" nslog="normal" nslog-type="10080012">关闭</span>
</li>
</ul>
</div></div>
</div>
<div class="declare-wrap" id="J-declare-wrap">
<div class="declare" id="J-declare">声明：百科词条人人可编辑，词条创建和修改均免费，绝不存在官方及代理商付费代编，请勿上当受骗。<a class="declare-details" target="_blank" href="/common/declaration">详情>></a>
<div class="close-btn" id="J-declare-close">
<em class="cmn-icon cmn-icons cmn-icons_close"></em>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="navbar-wrapper">
<div class="wgt-navbar">
<div class="navbar-bg">
<div class="navbar-bg-top">
<div class="navbar-content layout">
<div class="navbar-content-box">
<dl class="index ">
<dt><a href="/">首页</a></dt>
<dd>
<div><a href="/calendar/" target="_blank">历史上的今天</a></div>
<div><a href="/vbaike/" target="_blank">百科冷知识</a></div>
<div><a href="/vbaike#gallary" target="_blank">图解百科</a></div>
</dd>
</dl>
<dl class="cat ">
<dt><a>分类</a></dt>
<dd>
<div><a href="/art" target="_blank">艺术</a></div>
<div><a href="/science" target="_blank">科学</a></div>
<div><a href="/ziran" target="_blank">自然</a></div>
<div><a href="/wenhua" target="_blank">文化</a></div>
<div><a href="/dili" target="_blank">地理</a></div>
<div><a href="/shenghuo" target="_blank">生活</a></div>
<div><a href="/shehui" target="_blank">社会</a></div>
<div><a href="/renwu" target="_blank">人物</a></div>
<div><a href="/jingji" target="_blank">经济</a></div>
<div><a href="/tiyu" target="_blank">体育</a></div>
<div><a href="/lishi" target="_blank">历史</a></div>
</dd>
</dl>
<dl class="second-know ">
<dt><a>秒懂百科</a></dt>
<dd><div><a href="https://child.baidu.com/" target="_blank">懂啦</a></div>
<div><a href="/item/秒懂星课堂" target="_blank">秒懂星课堂</a></div>
<div><a href="/item/秒懂大师说" target="_blank">秒懂大师说</a></div>
<div><a href="/item/秒懂看瓦特" target="_blank">秒懂看瓦特</a></div>
<div><a href="/item/秒懂五千年" target="_blank">秒懂五千年</a></div>
<div><a href="/item/秒懂全视界" target="_blank">秒懂全视界</a></div>
</dd>
</dl>
<dl class="special ">
<dt><a>特色百科</a></dt>
<dd><div><a href="/museum/" target="_blank">数字博物馆</a></div>
<div><a href="/feiyi?fr=dhlfeiyi" target="_blank">非遗百科</a></div>
<div><a href="https://shushuo.baidu.com/" target="_blank">百度数说</a></div>
<div><a href="/city/" target="_blank">城市百科</a></div>
<div><a href="/wikicategory/view?categoryName=恐龙大全" target="_blank">恐龙百科</a></div>
<div><a href="/wikicategory/view?categoryName=多肉植物" target="_blank">多肉百科</a></div>
</dd>
</dl>
<dl class="user ">
<dt><a>用户</a></dt>
<dd>
<div><a href="/kedou/" target="_blank">蝌蚪团</a></div>
<div><a href="/event/ranmeng/" target="_blank">燃梦计划</a></div>
<div><a href="/task/" target="_blank">百科任务</a></div>
<div><a href="/mall/" target="_blank">百科商城</a></div>
</dd>
</dl>
<dl class="cooperation ">
<dt><a>权威合作</a></dt>
<dd>
<div><a href="/operation/cooperation#joint" target="_blank">合作模式</a></div>
<div><a href="/operation/cooperation#issue" target="_blank">常见问题</a></div>
<div><a href="/operation/cooperation#connection" target="_blank">联系方式</a></div>
</dd>
</dl>
<div class="usercenter">
<div><a href="/usercenter" target="_blank"><em class="cmn-icon cmn-icons cmn-icons_navbar-usercenter"></em>个人中心</a></div>
</div></div>
</div>
</div>
</div>
</div>
</div>


<div class="body-wrapper">
<div class="before-content">
<div class="page-background" style="display:block;position:relative;width:100%;height:480px;background:#f5f5f5 url('https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/pageBackground/img/noSecondKnow_df53ec5.png') no-repeat center 0px;">
<div class="bgMask"></div>
</div>
<div class="after-page-background" style="position:relative;margin-top:-460px;"></div>
</div>
<div class="content-wrapper">
<div class="content">
<div class="personal-content">
</div>
<div class="main-content">
<a class="posterFlag expert-icon " href="javascript:;" title="权威专家认证词条"></a>
<div class="top-tool">
<a class="add-sub-icon top-tool-icon" href="javascript:;" title="添加义项" nslog-type="50000101">
<em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_add-subLemma-solid"></em>
</a>
<a href="/divideload/%E5%8F%98%E7%94%B5%E7%AB%99" title="拆分词条" target="_blank" class="split-icon top-tool-icon" style="display:none;" nslog-type="50000104">
<em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_lemma-split"></em>
</a>
<div class="top-collect top-tool-icon" nslog="area" nslog-type="50000102">
<em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_star-solid"></em>
<span class="collect-text">收藏</span>
<div class="collect-tip">查看<a href="/uc/favolemma" target="_blank">我的收藏</a></div>
</div>
<a href="javascript:void(0);" id="j-top-vote" class="top-vote top-tool-icon" nslog-type="10060801">
<em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_zan-solid"></em>
<span class="vote-count">0</span>
<span class="vote-tip">有用+1</span>
<span class="voted-tip">已投票</span>
</a><div class="bksharebuttonbox top-share">
<a class="top-share-icon top-tool-icon" nslog-type="9067">
<em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_share"></em>
<span class="share-count" id="j-topShareCount">0</span>
</a>
<div class="new-top-share" id="top-share">
<ul class="top-share-list">
<li class="top-share-item">
<a class="share-link bds_qzone"  href="javascript:void(0);" nslog-type="10060501">
<em class="cmn-icon cmn-icons cmn-icons_logo-qzone"></em>
</a>
</li>
<li class="top-share-item">
<a class="share-link bds_tsina" href="javascript:void(0);" nslog-type="10060701">
<em class="cmn-icon cmn-icons cmn-icons_logo-sina-weibo"></em>
</a>
</li>
<li class="top-share-item">
<a class="bds_wechat"  href="javascript:void(0);" nslog-type="10060401">
<em class="cmn-icon cmn-icons cmn-icons_logo-wechat"></em>
</a>
</li>
<li class="top-share-item">
<a class="share-link bds_tqq"  href="javascript:void(0);" nslog-type="10060601">
<em class="cmn-icon cmn-icons cmn-icons_logo-qq"></em>
</a>
</li>
</ul>
</div>
</div>
</div>
<div style="width:0;height:0;clear:both"></div><dl class="lemmaWgt-lemmaTitle lemmaWgt-lemmaTitle-">
<dd class="lemmaWgt-lemmaTitle-title">
<span class="lemma-pinyin" >
<span class="text">[biàn diàn zhàn]</span>
<a class="speak" id="j-pinyin-speak" href="javascript:;" title="点击发声" nslog-type="10000106">&nbsp;</a>
</span>
<div id="fmp_flash_div" style="position:absolute; left:-9999px;">
<audio id="audio" src=""></audio>
</div>
<h1 >变电站</h1>
<a href="javascript:;" class="edit-lemma cmn-btn-hover-blue cmn-btn-28 j-edit-link"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
<a class="lock-lemma" nslog-type="10003105" target="_blank" href="javascript:;" title="锁定"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_lock-lemma"></em>锁定</a>
<a href="/planet/talk?lemmaId=7385877" target="_blank" class="lemma-discussion cmn-btn-hover-blue cmn-btn-28 j-discussion-link" nslog-type="90000102"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_discussion-solid"></em>讨论<span class="num">999</span></a>
</dd>
</dl><div class="authorityListPrompt">
<div class="main-content-zj">
本词条由<a href="https://baike.baidu.com/science" target="_blank" class="nslog:7175">“科普中国”科学百科词条编写与应用工作项目</a>
审核
。</div>
</div>
<div class="promotion-declaration">
</div><div class="lemma-summary" label-module="lemmaSummary">
<div class="para" label-module="para">变电站是指<a target=_blank href="/item/%E7%94%B5%E5%8A%9B%E7%B3%BB%E7%BB%9F/338401" data-lemmaid="338401">电力系统</a>中对电压和电流进行变换，接受电能及分配电能的场所。在<a target=_blank href="/item/%E5%8F%91%E7%94%B5%E5%8E%82/1419857" data-lemmaid="1419857">发电厂</a>内的变电站是<a target=_blank href="/item/%E5%8D%87%E5%8E%8B%E5%8F%98%E7%94%B5%E7%AB%99/5194413" data-lemmaid="5194413">升压变电站</a>，其作用是将<a target=_blank href="/item/%E5%8F%91%E7%94%B5%E6%9C%BA/995009" data-lemmaid="995009">发电机</a>发出的电能升压后馈送到高压电网中。</div>
</div>
<div class="configModuleBanner">
</div><div class="basic-info cmn-clearfix">
<dl class="basicInfo-block basicInfo-left">
<dt class="basicInfo-item name">中文名</dt>
<dd class="basicInfo-item value">
变电站
</dd>
<dt class="basicInfo-item name">外文名</dt>
<dd class="basicInfo-item value">
transformer station
</dd>
<dt class="basicInfo-item name">作&nbsp;&nbsp;&nbsp;&nbsp;用</dt>
<dd class="basicInfo-item value">
分配电能等
</dd>
</dl><dl class="basicInfo-block basicInfo-right">
<dt class="basicInfo-item name">设&nbsp;&nbsp;&nbsp;&nbsp;备</dt>
<dd class="basicInfo-item value">
变压器等
</dd>
<dt class="basicInfo-item name">应&nbsp;&nbsp;&nbsp;&nbsp;用</dt>
<dd class="basicInfo-item value">
发电厂输电等
</dd>
<dt class="basicInfo-item name">学&nbsp;&nbsp;&nbsp;&nbsp;科</dt>
<dd class="basicInfo-item value">
电力学
</dd>
</dl></div>
<div class="lemmaWgt-lemmaCatalog">
<div class="lemma-catalog">
<h2 class="block-title">目录</h2>
<div class="catalog-list column-3">
<ol>
<li class="level1">
<span class="index">1</span>
<span class="text"><a href="#1">分类</a></span>
</li>
<li class="level1">
<span class="index">2</span>
<span class="text"><a href="#2">设备</a></span>
</li>
</ol><ol><li class="level1">
<span class="index">3</span>
<span class="text"><a href="#3">布设要求</a></span>
</li>
<li class="level1">
<span class="index">4</span>
<span class="text"><a href="#4">巡检</a></span>
</li>
</ol><ol><li class="level1">
<span class="index">5</span>
<span class="text"><a href="#5">技术档案</a></span>
</li>
<li class="level1">
<span class="index">6</span>
<span class="text"><a href="#6">发展</a></span>
</li>
</ol>

</div>
</div>
</div>
<div class="anchor-list">
<a name="1" class="lemma-anchor para-title" ></a>
<a name="sub406127_1" class="lemma-anchor " ></a>
<a name="分类" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>分类</h2>
<a class="edit-icon j-edit-link" data-edit-dl="1" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">(1)一类变电站。是指交流特高压站，核电、大型能源基地（300万kw及以上）外送及跨大区（华北、华中、华东、东北、西北）联络750/500/330kV变电站。</div>
<div class="para" label-module="para">(2)二类变电站。是指除一类变电站以外的其他，750/500/330kV变电站，电厂外送变电站（100万kW及以上、300万kW以下）及跨省联络220kV变电站，主变压器或母线停运、开关拒动造成四级及以上电网事件的变电站。</div>
<div class="para" label-module="para">(3)三类变电站。是指除二类以外的220kV变电站，电厂外送变电站（30万kW及以上、100万kW以下），主变压器或母线停运、开关拒动造成五级电网事件的变电站，为一级及以上重要用户直接供电的变电站。</div>
<div class="para" label-module="para">(4)四类变电站。是指除一、二、三类以外的35kV及以上变电站。</div>
<div class="para" label-module="para">注：工区所有220kV变电站为三类变电站，110kV及以下所有变电站为四类变电站。<sup class="sup--normal" data-sup="1" data-ctrmap=":1,">
[1]</sup><a class="sup-anchor" name="ref_[1]_406127">&nbsp;</a>
</div><div class="anchor-list">
<a name="2" class="lemma-anchor para-title" ></a>
<a name="sub406127_2" class="lemma-anchor " ></a>
<a name="设备" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>设备</h2>
<a class="edit-icon j-edit-link" data-edit-dl="2" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">变电站内的电气设备分为一次设备和二次设备。下面对变电站内的主要设备进行简单的介绍。</div>
<div class="para" label-module="para">1、一次设备</div>
<div class="para" label-module="para">一次设备指直接生产、输送、分配和使用电能的设备，主要包括<a target=_blank href="/item/%E5%8F%98%E5%8E%8B%E5%99%A8">变压器</a>、<a target=_blank href="/item/%E9%AB%98%E5%8E%8B%E6%96%AD%E8%B7%AF%E5%99%A8">高压断路器</a>、<a target=_blank href="/item/%E9%9A%94%E7%A6%BB%E5%BC%80%E5%85%B3">隔离开关</a>、<a target=_blank href="/item/%E6%AF%8D%E7%BA%BF/10657310" data-lemmaid="10657310">母线</a>、<a target=_blank href="/item/%E9%81%BF%E9%9B%B7%E5%99%A8">避雷器</a>、<a target=_blank href="/item/%E7%94%B5%E5%AE%B9%E5%99%A8">电容器</a>、<a target=_blank href="/item/%E7%94%B5%E6%8A%97%E5%99%A8">电抗器</a>等。</div>
<div class="para" label-module="para">2、二次设备</div>
<div class="para" label-module="para">变电站的二次设备是指对一次设备和系统的运行工况进行测量、监视、控制和保护的设备，它主要由包括继电保护装置、自动装置、测控装置（<a target=_blank href="/item/%E7%94%B5%E6%B5%81%E4%BA%92%E6%84%9F%E5%99%A8">电流互感器</a>、<a target=_blank href="/item/%E7%94%B5%E5%8E%8B%E4%BA%92%E6%84%9F%E5%99%A8">电压互感器</a>）、计量装置、自动化系统以及为二次设备提供电源的直流设备。<sup class="sup--normal" data-sup="2" data-ctrmap=":2,">
[2]</sup><a class="sup-anchor" name="ref_[2]_406127">&nbsp;</a>
<a name="ref_2"></a></div><div class="anchor-list">
<a name="3" class="lemma-anchor para-title" ></a>
<a name="sub406127_3" class="lemma-anchor " ></a>
<a name="布设要求" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>布设要求</h2>
<a class="edit-icon j-edit-link" data-edit-dl="3" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">变电站的结构设计与设备布置一般具有如下要求：</div>
<div class="para" label-module="para">①建筑物底层的附属10 kV变电站不需分室，变压器及<a target=_blank href="/item/%E9%AB%98%E4%BD%8E%E5%8E%8B%E5%BC%80%E5%85%B3%E6%9F%9C">高低压开关柜</a>可同层同室布置，仅需保持特定间距，具有专有建筑物的35 kV独立变电站应按照功能分层分室布置；</div>
<div class="para" label-module="para">②变电站的室内布置应紧凑合理，便于运行人员的操作、检修、试验与巡视，开关柜安装位置应满足最小通道宽度要求，并适当考虑发展及扩建要求；</div>
<div class="para" label-module="para">③分室布置变电站应合理布置站内各功能室的位置，高压配电室与高压电容器室相邻，低压配电室与变压器室相邻，低压配电室应便于出线，控制室位置应便于运行人员的工作与管理；</div>
<div class="para" label-module="para">④高低压配电室的设施应符合安全与防火要求，站内不允许采用可燃材料装修；</div>
<div class="para" label-module="para">⑤高低压配电室、电容器室及变压器室的门应向外开，相邻两配电室的门应双向开启；</div>
<div class="para" label-module="para">⑥高低压配电室、电容器室、变压器室及主控室应设置防范雨、雪、蛇、鼠等从门、窗及缆沟入室的设施。<sup class="sup--normal" data-sup="3" data-ctrmap=":3,">
[3]</sup><a class="sup-anchor" name="ref_[3]_406127">&nbsp;</a>
</div><div class="anchor-list">
<a name="4" class="lemma-anchor para-title" ></a>
<a name="sub406127_4" class="lemma-anchor " ></a>
<a name="巡检" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>巡检</h2>
<a class="edit-icon j-edit-link" data-edit-dl="4" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">变电站的巡视检查就是值班人员通过定期巡视观察设备的外观有无异状，如颜色有无变化，有无杂物，表针指示是否正常，设备的声音是否正常，有无异常的气味，触及允许接触的设备温度是否正常，测量电气设备的运行参数在运行中的变化等，以判断设备的运行状况是否正常。</div>
<div class="para" label-module="para">变电站的巡视检查制度是确保设备正常安全运行的有效措施。通过值班人员的定期的巡视检查了解设备运行状况，掌握运行异常，并及时地采取相应措施，对于降低事故的发生及其影响范围具有重要意义。为此，变电站应根据运行设备的实际工况，并总结以往处理设备事故、障碍和缺陷的经验教训，制定出具体的检查方法。</div>
<div class="para" label-module="para">巡视检查制度应明确规定检查的项目及内容，周期和巡视检查的路线，并做好明显的标志。巡视检查的路线应根据设备区域和电气设备的检查项目和内容制定。有条件的变电站应配备必要的检查T具，在高峰负荷期，可采用红外线测温仪进行检查，另外，应保证充足良好的照明，为设备巡视提供必备条件。在夜间、恶劣气候下及特殊任务时特巡，要明确具体的巡视要求和注意事项，采取必要的措施，特巡必须有值班领导人参加。每次巡视检查后，应将检查的设备缺陷记入设备缺陷记录簿中，巡视检查人员对记录负责。<sup class="sup--normal" data-sup="4" data-ctrmap=":4,">
[4]</sup><a class="sup-anchor" name="ref_[4]_406127">&nbsp;</a>
</div><div class="anchor-list">
<a name="5" class="lemma-anchor para-title" ></a>
<a name="sub406127_5" class="lemma-anchor " ></a>
<a name="技术档案" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>技术档案</h2>
<a class="edit-icon j-edit-link" data-edit-dl="5" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">变电站必须建立以下技术档案。</div>
<div class="para" label-module="para">(1)设备制造厂家使用说明书；</div>
<div class="para" label-module="para">(2)电气设备出厂试验记录；</div>
<div class="para" label-module="para">(3)安装交接的有关资料；</div>
<div class="para" label-module="para">(4)电气设备的改进、大小修施工记录及施工报告；</div>
<div class="para" label-module="para">(5)电气设备历年大修及定期预防性施工报告；</div>
<div class="para" label-module="para">(6)电气设备事故、障碍及运行分析专题报告；</div>
<div class="para" label-module="para">(7)电气设备发生的严重缺陷、设备变动情况及改造记录。<sup class="sup--normal" data-sup="5" data-ctrmap=":5,">
[5]</sup><a class="sup-anchor" name="ref_[5]_406127">&nbsp;</a>
</div><div class="anchor-list">
<a name="6" class="lemma-anchor para-title" ></a>
<a name="sub406127_6" class="lemma-anchor " ></a>
<a name="发展" class="lemma-anchor " ></a>
</div><div class="para-title level-2" label-module="para-title">
<h2 class="title-text"><span class="title-prefix">变电站</span>发展</h2>
<a class="edit-icon j-edit-link" data-edit-dl="6" href="javascript:;"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-lemma"></em>编辑</a>
</div>
<div class="para" label-module="para">从第一个真正意义上的电力系统建立开始就出现了变电站，变电站作为电力系统不可或缺的部分，与电力系统共同发展了100多年，在这100多年的发展历程中，变电站在建造场地、电压等级、设备情况等方面都发生了巨大的变化。</div>
<div class="para" label-module="para">在变电站的建造场地上，由原来的全部敞开式户外变电站，逐步出现了户内变电站和一些<a target=_blank href="/item/%E5%9C%B0%E4%B8%8B%E5%8F%98%E7%94%B5%E7%AB%99">地下变电站</a>，变电站的占地面积与原来的敞开式户外变电站相比缩小了很多。</div>
<div class="para" label-module="para">在电压等级上，随着电力技术的发展，由原来以少量110kV和220kV变电站为枢纽变电站。35kV为终端变电站的小电网输送模式，逐步发展成以特高压1000kV变电站和500kV变电站为枢纽变电站，220kV、110kV变电站为终端变电站的大电网输送模式。</div>
<div class="para" label-module="para">在电气设备方面，一次设备由原来敞开式的户外设备为主，逐步发展到全封闭气体组合电器（GIS）和半封闭气体组合电器（HGIS）；二次设备由早期的晶体管和集成电路保护发展到微机保护。<sup class="sup--normal" data-sup="2" data-ctrmap=":2,">
[2]</sup><a class="sup-anchor" name="ref_[2]_406127">&nbsp;</a>
<a name="ref_2"></a></div>
<div class="anchor-list">
<a name="a" class="lemma-anchor a" ></a>
</div><div class="album-list">
<div class="header">
<span class="title">词条图册</span>
<a class="more-link" href="/pic/%E5%8F%98%E7%94%B5%E7%AB%99/7385877?fr=lemma" target="_blank" nslog-type="10000204">更多图册<em></em></a>
</div>
<div class="scroller">
<div class="list">
</div>
</div>
<div class="footer">
</div>
</div>
<div class="rs-container-foot">
<a name="rs-1"></a>
<a name="rs_406127_35403" class="anchor-2"></a>
<div id="rs-container-406127-35403" class="rslazy rs-container" lazy-init="lemmars.tableAction(baidu.g('rs-406127-35403'))"></div>
</div><script type="text/javascript">
        window.rsInsertData = window['rsInsertData'] || [];
        var rsdataList = {"foot":[{"fentryTableId":35403,"fentryTableName":"\u53d8\u7535","fentryTableType":1,"entryId":2672746,"templateId":0,"entryTitle":"\u53d8\u7535","isManual":0,"isExpand":1}],"top":[]};

        if (rsdataList.top || rsdataList.foot) {
            rsInsertData.push([406127, rsdataList]);
        }
    </script>
<dl class="lemma-reference collapse nslog-area log-set-param" data-nslog-type="2" log-set-param="ext_reference">
<dt class="reference-title">参考资料</dt>
<dd class="reference-list-wrap">
<ul class="reference-list">
<li class="reference-item reference-item--type2 " id="reference-[1]-406127-wrap">
<span class="index">1.</span>
<a class="gotop anchor"  name="refIndex_1_406127" id="refIndex_1_406127" title="向上跳转" href="#ref_[1]_406127">&nbsp;&nbsp;</a>
<span>张涛主编；郭跃东，王晓红，司毅峰等副主编</span><span class="text">．变电运维技能培训教材</span><span>：中国电力出版社</span><span>，2016.07</span></li><li class="reference-item reference-item--type2 " id="reference-[2]-406127-wrap">
<span class="index">2.</span>
<a class="gotop anchor"  name="refIndex_2_406127" id="refIndex_2_406127" title="向上跳转" href="#ref_[2]_406127">&nbsp;&nbsp;</a>
<span>杜晓平丛书主编；杜晓平，郭伯宙本书主编</span><span class="text">．110KV变电站变电运维技术</span><span>：中国水利水电出版社</span><span>，2016.01</span></li><li class="reference-item reference-item--type2 " id="reference-[3]-406127-wrap">
<span class="index">3.</span>
<a class="gotop anchor"  name="refIndex_3_406127" id="refIndex_3_406127" title="向上跳转" href="#ref_[3]_406127">&nbsp;&nbsp;</a>
<span>靖大为主编</span><span class="text">．城市供电技术</span><span>：天津大学出版社</span><span>，2009.1</span></li><li class="reference-item reference-item--type2 " id="reference-[4]-406127-wrap">
<span class="index">4.</span>
<a class="gotop anchor"  name="refIndex_4_406127" id="refIndex_4_406127" title="向上跳转" href="#ref_[4]_406127">&nbsp;&nbsp;</a>
<span>广东电网公司组编</span><span class="text">．电力专业知识</span><span>：广东高等教育出版社</span><span>，2008.07</span></li><li class="reference-item reference-item--type2 " id="reference-[5]-406127-wrap">
<span class="index">5.</span>
<a class="gotop anchor"  name="refIndex_5_406127" id="refIndex_5_406127" title="向上跳转" href="#ref_[5]_406127">&nbsp;&nbsp;</a>
<span>李瑞荣编著</span><span class="text">．用户变配电站电气运行技术问答</span><span>：中国电力出版社</span><span>，2008.08</span></li></ul>
</dd>
</dl>
<div id="open-tag">
<div class="open-tag-title">词条标签：</div>
<dd id="open-tag-item">
<span class="taglist">
<a target="_blank" href="/wikitag/taglist?tagId=76600">科学百科工程技术分类</a>
</span>
，<span class="taglist">
社会
</span>
</dd>
<div class="open-tag-collapse" id="open-tag-collapse"></div>
</div>
<div class="clear"></div>
</div>
<div class="side-content">
<div class="summary-pic">
<a href="/pic/%E5%8F%98%E7%94%B5%E7%AB%99/7385877/0/35a85edf8db1cb1344448ecad654564e92584b3d?fr=lemma&amp;ct=single" target="_blank" nslog-type="10002401">
<img src="https://gss1.bdstatic.com/-vo3dSag_xI4khGkpoWK1HF6hhy/baike/w%3D268%3Bg%3D0/sign=ac9b003f2c7f9e2f70351a0e270b8e19/35a85edf8db1cb1344448ecad654564e92584b3d.jpg" />
<button class="picAlbumBtn"><em></em><span>图集</span></button>
<div>变电站图册</div>
</a>
</div>
<div class="professional-con">
<div class="professional-header">
<div style="background-image: url('https://gss0.bdstatic.com/94o3dSag_xI4khGkpoWK1HF6hhy/baike/w%3D50/sign=a88888073f7adab43dd01b438ad4bcdd/b3119313b07eca8035a902c8982397dda1448374.jpg')">
<h2 title="科普中国">科普中国</h2>
<p title="致力于权威的科学传播">致力于权威的科学传播</p>
</div>
</div>
<div class="professional-content">
<div class="professional-title professional-clearfix">
<h3>本词条认证专家为</h3>
</div>
<div class="professional-list" id="professional_list">
<div class="professional-list-slider J-slider">
<ul>
<li class="professional-clearfix">
<div class="pro-line"></div>
<div class="pro-content">
<div class="pro-content-title professional-clearfix">
<h4>王沛</h4>
<span>副教授、副研究员</span><i>审核</i></div>
<p title="中国科学院工程热物理研究所">中国科学院工程热物理研究所</p>
</div>
</li>
</div>
</div>
</div>
</div>
<div class="lemmaWgt-promotion-vbaike">
<div class="promotion_title">V百科<a href="/vbaike#gallary" target="_blank">往期回顾</a></div>
<div class="promotion_viewport">
<dl>
</dl>
<div class="promotion_viewport_pager"></div>
</div>
</div><div class="lemmaWgt-promotion-rightPreciseAd" data-lemmaId="7385877" data-lemmaTitle="变电站"></div><div class="lemmaWgt-sideRecommend">
<a name="zhixinWrap" class="qnAnchor"></a>
<div class="zhixin-box" id="zhixinWrap" data-source="" data-newLemmaId="7385877">
</div>
<form id="zhixinErrorForm" class="hidden" action="https://sp2.baidu.com/-uV1bjeh1BF3odCf/index.php/feedback/zx/baikeJC" target="zhixinSubErr" method="post">
<input class="js-url" name="fb_html_url" type="hidden" />
<input class="js-query" name="fb_query" type="hidden" />
<input class="js-title" name="fb_card_title" type="hidden" />
<input class="js-content" name="fb_content" type="hidden" />
<input class="js-souceId" name="fb_source_id" type="hidden" />
</form>
<iframe id="zhixinSubErr" name="zhixinSubErr" style="display:none" frameborder="0"></iframe>
</div>
<div class="lemmaWgt-promotion-slide">
<div class="promotion_viewport">
<dl>
</dl>
<div class="promotion_viewport_pager"></div>
</div>
</div><div class="lemmaWgt-promotion-rightBigAd">
</div><div id="side-auth">
<div id="authEdit" class="side-box">
<dl>
<dt class="sidetitle">权威合作编辑</dt>
<dd class="side-auth-content">
<div class="side-auth-img">
<a href="http://www.kepuchina.cn" target="_blank" class="nslog:7075" id="authOrgRightEditPic">
<img style="display: none" onload="this.style.width = '50px';this.style.display='';" src="https://baike.baidu.com/cms/rc/QQ%E5%9B%BE%E7%89%8720141121003618.jpg" alt="权威编辑" title="权威编辑"/>
</a>
</div>
<div class="side-auth-info">
<p class="auth-info-name">
<a href="http://www.kepuchina.cn" nslog-type="7075" target="_blank" id="authOrgRightEdit">“科普中国”科学百科词条编写与应用工作项目</a>
</p>
<span id="authDetail">
“科普中国”是为我国科普信息化建设塑造的全...
</span>
</div>
<div class="clear"></div>
</dd>
<dd class="authVersion">
<span style="">
<a class="whatIs" align="absmiddle" href="javascript:void(0);"></a><a href=" http://baike.bdimg.com/cms/static/cooperation/content.pdf" target="_blank" nslog-type="36" class="link-toggle" id="whatIsAuthEdit">什么是权威编辑</a>
</span>
<span class="divisionLine"></span>
<a href="/history/%E5%8F%98%E7%94%B5%E7%AB%99/7385877/125594522" class="nslog:37" target="_blank" id="authEditVersion">查看编辑版本</a>
</dd>
</dl>
</div>
</div>
<dl class="side-box lemma-statistics">
<dt class="title">词条统计</dt>
<dd class="description ">
<ul>
<li>浏览次数：<span id="j-lemmaStatistics-pv"></span>次</li>
<li>编辑次数：78次<a href="/historylist/%E5%8F%98%E7%94%B5%E7%AB%99/7385877" class="nslog:1021" target="_blank">历史版本</a></li>
<li>
<span class="latest-title">最近更新：</span>
<span class="latest-content">
<a class="show-userCard" data-uid="186670569" title="查看此用户资料" target="_blank" href="/usercenter/userpage?uname=%E5%8D%9C%E9%A1%B9%E7%A6%BB&from=lemma"
                    nslog-type="1022">卜项离</a><span class="j-modified-time" style="display:none">（2019-02-27）</span>
</span>
</li>
</ul>
</dd>
</dl>
<div class="side-catalog" style="visibility:hidden">
<div class="side-bar">
<em class="circle start"></em>
<em class="circle end"></em>
</div>
<div class="catalog-scroller">
<dl class="catalog-list">
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#1" class="title-link">
<span class="text">
<span class="title-index">1</span>
<span class="title-link" nslog-type="10002802">分类</span>
</span>
</a>
</dt>
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#2" class="title-link">
<span class="text">
<span class="title-index">2</span>
<span class="title-link" nslog-type="10002802">设备</span>
</span>
</a>
</dt>
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#3" class="title-link">
<span class="text">
<span class="title-index">3</span>
<span class="title-link" nslog-type="10002802">布设要求</span>
</span>
</a>
</dt>
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#4" class="title-link">
<span class="text">
<span class="title-index">4</span>
<span class="title-link" nslog-type="10002802">巡检</span>
</span>
</a>
</dt>
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#5" class="title-link">
<span class="text">
<span class="title-index">5</span>
<span class="title-link" nslog-type="10002802">技术档案</span>
</span>
</a>
</dt>
<dt class="catalog-title level1">
<em class="pointer"></em>
<a href="#6" class="title-link">
<span class="text">
<span class="title-index">6</span>
<span class="title-link" nslog-type="10002802">发展</span>
</span>
</a>
</dt>
<a class="arrow" href="javascript:void(0);"></a>
</dl>
</div>
<div class="right-wrap">
<a class="go-up disable" href="javascript:void(0);"></a>
<a class="go-down" href="javascript:void(0);"></a>
</div>
<div class="bottom-wrap">
<a class="toggle-button" href="javascript:void(0);" nslog-type="10002803"></a>
<a class="gotop-button" href="javascript:void(0);" nslog-type="10002804"></a>
</div>
</div>
<div id="side_box_fengchao" class="fengchao side-box" nslog="area" nslog-type="10000902">
</div>
<div id="side_box_unionAd" class="unionAd side-box">
<div class="union-content"></div>
</div>
</div>
</div>
</div>
<div class="after-content">
<div class="fc-guess-like new" id="fc_guess_like_new">
<span class="logo-du">
<em class="cmn-icon cmn-icons cmn-icons_logo-du"></em>
</span>
<h6>猜你关注</h6>
<ul class="cmn-clearfix">
</ul>
</div>
</div>
</div>

<div class="wgt-footer-main">
<div class="content">
<dl class="fresh">
<dt><em class="cmn-icon cmn-icons cmn-icons_footer-fresh"></em>新手上路</dt>
<dd>
<div><a target="_blank" href="/usercenter/tasks#guide">成长任务</a></div>
<div><a target="_blank" href="/help#main01">编辑入门</a></div>
<div><a target="_blank" href="/help#main06">编辑规则</a></div>
<div><a target="_blank" href="/item/%E7%99%BE%E5%BA%A6%E7%99%BE%E7%A7%91%EF%BC%9A%E6%9C%AC%E4%BA%BA%E8%AF%8D%E6%9D%A1%E7%BC%96%E8%BE%91%E6%9C%8D%E5%8A%A1/22442459?bk_fr=pcFooter">本人编辑</a><img src="https://bkssl.bdimg.com/static/wiki-common/widget/component/footer/img/new-icon_a64774d.png" class="new-icon" alt="new"></div>
</dd>
</dl>
<dl class="question">
<dt><em class="cmn-icon cmn-icons cmn-icons_footer-question"></em>我有疑问</dt>
<dd>
<div><a id="J-bk-feedback-query" data-lemma="变电站" href="javascript:void(0);" nslog-type="10070001">内容质疑</a></div>
<div><a target="_blank" href="http://zhiqiu.baidu.com/baike/passport/html/baikechat.html" nslog-type="10000003">在线客服</a></div>
<div><a target="_blank" href="http://tieba.baidu.com/f?ie=utf-8&fr=bks0000&kw=%E7%99%BE%E5%BA%A6%E7%99%BE%E7%A7%91">官方贴吧</a></div>
<div><a id="J-bk-feedback-main" href="javascript:void(0);">意见反馈</a></div>
</dd>
</dl>
<dl class="suggestion">
<dt><em class="cmn-icon cmn-icons cmn-icons_footer-suggestion"></em>投诉建议</dt>
<dd>
<div><a target="_blank" href="http://help.baidu.com/newadd?prod_id=10&category=1">举报不良信息</a></div>
<div><a target="_blank" href="http://help.baidu.com/newadd?prod_id=10&category=2">未通过词条申诉</a></div>
<div><a target="_blank" href="http://help.baidu.com/newadd?prod_id=10&category=6">投诉侵权信息</a></div>
<div><a target="_blank" href="http://help.baidu.com/newadd?prod_id=10&category=5">封禁查询与解封</a></div>
</dd>
</dl>
</div>
<div class="copyright">©2019&nbsp;Baidu&nbsp;<a href="http://www.baidu.com/duty/" target="_blank">使用百度前必读</a>&nbsp;|&nbsp;<a href="http://help.baidu.com/question?prod_en=baike&class=89&id=1637" target="_blank">百科协议</a>&nbsp;|&nbsp;<a href="http://help.baidu.com/question?prod_id=10&class=690&id=1001779" target="_blank">隐私政策</a>&nbsp;|&nbsp;<a href="/operation/cooperation" target="_blank">百度百科合作平台</a>&nbsp;|&nbsp;<span>京ICP证030173号&nbsp;</span><img class="copyright-img" width="13" height="16" src="https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/copy_rignt_24.png"></div>
<p class="recordcode"><a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11000002000001" target="_blank"><i class="icon-police"></i>京公网安备11000002000001号</a></p>
</div>


<div class="lemmaWgt-searchHeader">
<div class="layout cmn-clearfix">
<div class="wgt-searchbar wgt-searchbar-new wgt-searchbar-simple cmn-clearfix ">
<div class="logo-container">
<a class="logo cmn-inline-block" title="到百科首页" href="/">
<span class="cmn-baike-logo">
<em class="cmn-icon cmn-icons cmn-icons_logo-bai"></em>
<em class="cmn-icon cmn-icons cmn-icons_logo-du"></em>
<em class="cmn-icon cmn-icons cmn-icons_logo-baike"></em>
</span>
</a>
</div>
<div class="search">
<div class="form">
<form id="searchForm" action="/search/word" method="GET" target="_self">
<input id="query" nslog="normal" nslog-type="10080015" name="word" type="text" autocomplete="off" autocorrect="off" value="变电站" /><button id="search" nslog="normal" nslog-type="10080013" type="button">进入词条</button>
</form>
<form id="searchLemmaForm" action="/search" method="GET" target="_self">
<input id="searchLemmaQuery" name="word" type="hidden" />
<input name="pn" type="hidden" value="0" />
<input name="rn" type="hidden" value="0" />
<input name="enc" type="hidden" value="utf8" />
</form>
<ul id="suggestion" class="suggestion">
<div class="sug"></div>
<li class="extra">
<span id="clear" style="margin-right:8px;">清除历史记录</span><span id="close" nslog="normal" nslog-type="10080016">关闭</span>
</li>
</ul>
</div>
</div>
</div>
<div class="tool-buttons">
<a class="toolButtons-edit button j-edit-link" href="javascript:;" nslog-type="10010001"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_edit-hollow"></em>编辑</a>
<a class="toolButtons-discussion button j-discussion-link" href="/planet/talk?lemmaId=7385877" target="_blank" nslog-type="90000103"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_discussion-hollow"></em>讨论&nbsp;<span class="num">66</span></a>
<a class="toolButtons-collect button" href="javascript:;" nslog-type="10010002"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_star-hollow"></em><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_star-solid"></em>收藏</a>
<a class="toolButtons-vote button top-vote" href="javascript:;" nslog-type="10010003"><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_zan-hollow"></em><em class="cmn-icon wiki-lemma-icons wiki-lemma-icons_zan-solid"></em><span class="j-tool-btn-vote-num">赞</span></a>
</div>
<div class="user-info">
<a class="user-link unlogin" href="javascript:;" nslog-type="10010008" target="_blank">登录</a>
</div>
</div></div>
<div class="new-bdsharebuttonbox new-side-share" id="side-share">
<span class="title">分享</span>
<div class="side-border">
<div class="triangle"></div>
<a class="share-link bds_qzone"  href="javascript:void(0);" nslog-type="10060101">
<em class="cmn-icon cmn-icons cmn-icons_logo-qzone"></em>
</a>
<a class="share-link bds_tsina" href="javascript:void(0);" nslog-type="10060301">
<em class="cmn-icon cmn-icons cmn-icons_logo-sina-weibo"></em>
</a>
<a class="bds_wechat"  href="javascript:void(0);" nslog-type="10060001">
<em class="cmn-icon cmn-icons cmn-icons_logo-wechat"></em>
</a>
<a class="share-link bds_tqq"  href="javascript:void(0);" nslog-type="10060201">
<em class="cmn-icon cmn-icons cmn-icons_logo-qq"></em>
</a>
</div>
</div>
<div class="qrcode-wrapper" id="layer" style="display: none">
<div class="bd_weixin_popup_header">
<em class="cmn-icon cmn-icons cmn-icons_close"></em>
<span>分享到微信朋友圈</span>
</div>
<div id="wechat-qrcode-img"></div>
<div class="bd_weixin_popup_footer">打开微信“扫一扫”即可将网页分享至朋友圈</div>
</div>
<div></div><div></div>
<script>
      window['__abbaidu_2020_subidgetf'] = function () {
          var subid = 01000000;
          return subid;
      };
    </script>
<script async src="https://dlswbr.baidu.com/heicha/mw/abclite-2020-s.js"></script>

</body><script type="text/javascript" src="https://bkssl.bdimg.com/static/wiki-common/js/mod_4302fe0.js"></script>
<script type="text/javascript">require.resourceMap({"res":{"wiki-lemma:widget/lemma_content/mainContent/lemmaRelation/lemmaInsert.js":{"url":"https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/lemmaRelation/lemmaInsert_18f1b51.js","pkg":"wiki-lemma:p5","deps":["wiki-common:widget/component/nslog/nslog.js"]},"wiki-lemma:widget/lemma_content/mainContent/lemmaRelation/tangram.js":{"url":"https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/lemmaRelation/tangram_459492a.js","pkg":"wiki-lemma:p5"},"wiki-lemma:widget/lemma_content/mainContent/lemmaReference/lemmaReferenceTip/lemmaReferenceTip.js":{"url":"https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/mainContent/lemmaReference/lemmaReferenceTip/lemmaReferenceTip_3a154ae.js","deps":["wiki-common:widget/lib/jquery/jquery.js","wiki-common:widget/lib/jsmart/jsmart.js","wiki-common:widget/component/nslog/nslog.js"]}},"pkg":{"wiki-lemma:p5":{"url":"https://bkssl.bdimg.com/static/wiki-lemma/pkg/wiki-lemma-module-lemmaRelation_853c311.js"}}});</script><script type="text/javascript" src="https://bkssl.bdimg.com/static/wiki-common/pkg/wiki-common-base_ce31a9e.js"></script>
<script type="text/javascript" src="https://bkssl.bdimg.com/static/wiki-lemma/pkg/wiki-lemma_95ddd0e.js"></script>
<script type="text/javascript" src="https://bkssl.bdimg.com/static/wiki-lemma/widget/lemma_content/configModule/zhixin/zhixin_58e6342.js"></script>
<script type="text/javascript">!function(){  var $ = require('wiki-common:widget/lib/jquery/jquery'),
    userbar = require('wiki-common:widget/component/userbar-n/userbar-n');
    
  userbar.buildUserbar($('#j-wgt-userbar'), null);
}();
!function(){  require('wiki-common:widget/component/headTabBar/headTabBar');
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery'),
      initSearchbar = require('wiki-common:widget/component/searchbar-n/searchbar');  
    initSearchbar($('.wgt-searchbar-main'));
  }();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var cookie = require('wiki-common:widget/util/cookie');
    if (!cookie.get('baikedeclare')) {
        $('#J-declare-wrap').css('display', 'block');
    }
    $('#J-declare-close').on('click', function () {
        // 用户关闭后，不再显示，这里暂设过期时间为1年
        cookie.set('baikedeclare', 'showed', {
            expires: 365 * 60 * 60 * 24 * 1000,
            path: '/'
        });
        $('#J-declare-wrap').css('display', 'none');
    });
}();
!function(){var $ = require('wiki-common:widget/lib/jquery/jquery');

var timer = '';

$('.wgt-navbar').on('mouseenter', 'dl', function() {
  clearTimeout(timer);
  timer = setTimeout(function() {
    $('.wgt-navbar').addClass('wgt-navbar-hover');
  }, 300);
}).on('mouseleave', function() {
  clearTimeout(timer);
  $('.wgt-navbar').removeClass('wgt-navbar-hover');
}).on('click', 'a', function() {
  clearTimeout(timer);
  $('.wgt-navbar').removeClass('wgt-navbar-hover');
});
}();
!function(){                var $ = require('wiki-common:widget/lib/jquery/jquery');
                var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

                // 展现策略
                rightCheck.editView('7385877', function(res) {
                    if (!res.errno) {
                        if (res.data.edit) {
                            $('.lemmaWgt-lemmaTitle .add-subLemma').css('display', 'inline-block');
                            $('.top-tool .add-sub-icon').css('display', 'inline-block');
                        }
                    } else {
                        if ('1') {
                            $('.lemmaWgt-lemmaTitle .add-subLemma').css('display', 'inline-block');
                            $('.top-tool .add-sub-icon').css('display', 'inline-block');
                        }
                    }
                });
                require('wiki-lemma:widget/basicElement/addSub/addSub.js')({                    lemmaId: '7385877',                    lemmaTitle:"\u53d8\u7535\u7ad9",                    lemmaDesc:null,                    versionId: '136112321',                    subLemmaId: '406127'                });
            }();
!function(){        var $ = require('wiki-common:widget/lib/jquery/jquery');
        var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

        // 展现策略
        rightCheck.editView('7385877', function(res) {
            if (!res.errno) {
                if (res.data.divide) {
                    $('.top-tool .split-icon').css('display', 'block');
                }
            }
        });
    }();
!function(){    var nslog = require('wiki-common:widget/component/nslog/nslog');
	require.async(["wiki-lemma:widget/basicElement/collect/collect"],function(collect){
		collect({
            newLemmaId:"7385877",
			lemmaId:"406127",
			subLemmaId:"406127"
		});
	});
}();
!function(){    require.async(["wiki-lemma:widget/basicElement/topShare/topShare"],function(topShare){
        topShare({
            newLemmaId: '7385877'
        });
    });
}();
!function(){    require('wiki-lemma:widget/basicElement/pinyin/lemmaPinyin')({
        lemmaTitle: '变电站',
        pinyin: "bian4 dian4 zhan4"
    });

   var nslog = require('wiki-common:widget/component/nslog/nslog');
   nslog(10000105);

}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');
    var nsLog = require('wiki-common:widget/component/nslog/nslog');
    var Dialog = require("wiki-common:widget/ui/dialog/dialog");
    
    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.lemmaWgt-lemmaTitle .edit-lemma').css('display', 'inline-block');
                // 编辑和申请本人实名验证保证同一行展示
                if ($('.lemmaWgt-lemmaTitle .personal').length > 0) {
                  if ($('.lemmaWgt-lemmaTitle .edit-lemma').offset().left > $('.lemmaWgt-lemmaTitle .personal').offset().left) {
                    $('.lemmaWgt-lemmaTitle .edit-lemma').before('<br/><br/>');
                  }
                }
            } else {
                nsLog('10003104');              
                $('.lemmaWgt-lemmaTitle .lock-lemma').show();
                // 锁定和申请本人实名验证保证同一行展示
                if ($('.lemmaWgt-lemmaTitle .personal').length > 0) {
                  if ($('.lemmaWgt-lemmaTitle .lock-lemma').offset().left > $('.lemmaWgt-lemmaTitle .personal').offset().left) {
                    $('.lemmaWgt-lemmaTitle .lock-lemma').before('<br/><br/>');
                  }
                }
            }
        } else {
            if ('1') {
                $('.lemmaWgt-lemmaTitle .edit-lemma').css('display', 'inline-block');
                // 编辑和申请本人实名验证保证同一行展示
                if ($('.lemmaWgt-lemmaTitle .personal').length > 0) {
                  if ($('.lemmaWgt-lemmaTitle .edit-lemma').offset().left > $('.lemmaWgt-lemmaTitle .personal').offset().left) {
                    $('.lemmaWgt-lemmaTitle .edit-lemma').before('<br/><br/>');
                  }
                }
            } else {
                nsLog('10003104');  
                $('.lemmaWgt-lemmaTitle .lock-lemma').show();
                // 锁定和申请本人实名验证保证同一行展示
                if ($('.lemmaWgt-lemmaTitle .personal').length > 0) {
                  if ($('.lemmaWgt-lemmaTitle .lock-lemma').offset().left > $('.lemmaWgt-lemmaTitle .personal').offset().left) {
                    $('.lemmaWgt-lemmaTitle .lock-lemma').before('<br/><br/>');
                  }
                }
            }
        }
    });

    var canDiscussion = $('.j-discussion-link').length > 0 ? true : false;
    if (canDiscussion) {
        // 锁定跳转
        $('body').on('click', '.lock-lemma', function () {
            var me = $(this);
            var content = '<div style="text-align: left;width: 528px">'
                + '<h2 style="font-size: 20px;color: #333;line-height: 26px;margin-bottom: 20px;">' 
                + '词条锁定，暂时无法编辑</h2>' 
                + '<p style="font-size: 16px;color: #333;line-height: 26px;">'
                + '亲爱的用户，词条存在争议或词条内容较完善都可能被锁定（'
                + '<a href="/view/10812319.htm" target="_blank">查看详情</a>）。</p>'
                + '<p style="font-size: 16px;color: #333;line-height: 26px;">'
                + '如果你认为锁定词条内容存在问题需要修改，可进行以下操作：</p></div>';
            new Dialog({
                title: '编辑提示',
                content: content,
                btns: [
                    {
                        text: '<span style="font-size: 14px">参与词条讨论，反馈词条问题</span>',
                        key: 'discussion'
                    }
                ],
                onBtnClick: function(btnKey){
                    if (btnKey === 'discussion') {
                        window.location.href = '/planet/talk?lemmaId=7385877&category=1';
                    }
                }
            }).show();
        });
        // 获取讨论数
        $.get('/discussion/api/getdiscussioncount?lemmaId=7385877', function (res) {
            if (res && res.errno === 0 && res.data.discussionCount > 0) {
                var numText = res.data.discussionCount <= 99 ? res.data.discussionCount : '99+';
                $('.j-discussion-link .num').text(numText).show();
            }
        });
        $('.lemmaWgt-lemmaTitle .j-discussion-link').on('click', function () {
            $(this).find('.num').remove();
        });
        // 讨论按钮展现量
        nsLog(90000101, window.location.href, {
            lemmaid: 7385877
        });
    }
}();
!function(){	require('wiki-lemma:widget/lemma_content/mainContent/basicInfo/basicInfo')();
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var nslog = require('wiki-common:widget/component/nslog/nslog');
    nslog(10002701);
    $('.lemmaWgt-lemmaCatalog a').on('click', function () {
           nslog(10002702);
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');

    // 展现策略
    rightCheck.editView('7385877', function(res) {
        if (!res.errno) {
            if (res.data.edit) {
                $('.para-title .edit-icon').css('display', 'block');
            }
        } else {
            if ('1') {
                $('.para-title .edit-icon').css('display', 'block');
            }
        }
    });
}();
!function(){	require.async(["wiki-common:widget/lib/jquery/jquery","wiki-lemma:widget/lemma_content/mainContent/albumList/albumList","wiki-common:widget/component/nslog/nslog"],function($,AlbumList,nslog){
		var list=new AlbumList({
			newLemmaId:"7385877",
			lemmaTitle:"变电站",
			lemmaId:"406127",
			subLemmaId:"406127",
			data:{"257265":{"coverpic":"9e3df8dcd100baa17d4c66d84710b912c8fc2e74","desc":"\u9752\u6d77\u7701\u7535\u529b\u516c\u53f8\u65e5\u6708\u5c71750kV\u53d8\u7535\u7ad9","albumTag":"null","height":626,"width":935,"total":1,"coverurl":"https:\/\/gss0.bdstatic.com\/94o3dSag_xI4khGkpoWK1HF6hhy\/baike\/s%3D235\/sign=9da8f4ad9925bc312f5d069b6bde8de7\/9e3df8dcd100baa17d4c66d84710b912c8fc2e74.jpg"},"0":{"coverpic":"35a85edf8db1cb1344448ecad654564e92584b3d","width":426,"height":400,"desc":"\u8bcd\u6761\u56fe\u7247","total":2,"coverurl":"https:\/\/gss1.bdstatic.com\/-vo3dSag_xI4khGkpoWK1HF6hhy\/baike\/s%3D235\/sign=3cbd4c067d094b36df921cee96cd7c00\/35a85edf8db1cb1344448ecad654564e92584b3d.jpg"}}
		});
		!!window.ScriptLazyLoad && window.ScriptLazyLoad.regist({
			dom:$('.album-list'),
			loadFunc:function(){
				list.load();
				nslog(1258);
			},
			distance:500
		});
	});
}();
!function(){        require.async(['wiki-lemma:widget/lemma_content/mainContent/lemmaRelation/lemmaInsert'], function(init) {
            init({ // 关系化统计需求--传参  shangwenbin
                lemmaId: "406127",
                newLemmaId: "7385877",
                subLemmaId: "406127",
                lemmaTitle: "变电站"
            });
        });
    }();
!function(){		require.async(["wiki-lemma:widget/lemma_content/mainContent/lemmaReference/lemmaReference","wiki-lemma:widget/lemma_content/mainContent/lemmaReference/lemmaReferenceTip/lemmaReferenceTip"],function(Reference,ReferenceTip){
			new Reference({
				subLemmaId:"406127"
			});
			new ReferenceTip({
				subLemmaId:"7385877",
				lemmaTitle:"变电站",
				reference:[{"type":"2","author":"\u5f20\u6d9b\u4e3b\u7f16\uff1b\u90ed\u8dc3\u4e1c\uff0c\u738b\u6653\u7ea2\uff0c\u53f8\u6bc5\u5cf0\u7b49\u526f\u4e3b\u7f16","title":"\u53d8\u7535\u8fd0\u7ef4\u6280\u80fd\u57f9\u8bad\u6559\u6750","publisher":"\u4e2d\u56fd\u7535\u529b\u51fa\u7248\u793e","place":"","publishYear":"2016.07","refPage":"","index":1},{"type":"2","author":"\u675c\u6653\u5e73\u4e1b\u4e66\u4e3b\u7f16\uff1b\u675c\u6653\u5e73\uff0c\u90ed\u4f2f\u5b99\u672c\u4e66\u4e3b\u7f16","title":"110KV\u53d8\u7535\u7ad9\u53d8\u7535\u8fd0\u7ef4\u6280\u672f","publisher":"\u4e2d\u56fd\u6c34\u5229\u6c34\u7535\u51fa\u7248\u793e","place":"","publishYear":"2016.01","refPage":"","index":2,"count":"2"},{"type":"2","author":"\u9756\u5927\u4e3a\u4e3b\u7f16","title":"\u57ce\u5e02\u4f9b\u7535\u6280\u672f","publisher":"\u5929\u6d25\u5927\u5b66\u51fa\u7248\u793e","place":"","publishYear":"2009.1","refPage":"","index":3},{"type":"2","author":"\u5e7f\u4e1c\u7535\u7f51\u516c\u53f8\u7ec4\u7f16","title":"\u7535\u529b\u4e13\u4e1a\u77e5\u8bc6","publisher":"\u5e7f\u4e1c\u9ad8\u7b49\u6559\u80b2\u51fa\u7248\u793e","place":"","publishYear":"2008.07","refPage":"","index":4},{"type":"2","author":"\u674e\u745e\u8363\u7f16\u8457","title":"\u7528\u6237\u53d8\u914d\u7535\u7ad9\u7535\u6c14\u8fd0\u884c\u6280\u672f\u95ee\u7b54","publisher":"\u4e2d\u56fd\u7535\u529b\u51fa\u7248\u793e","place":"","publishYear":"2008.08","refPage":"","index":5}]
			});
		});
	}();
!function(){        require.async(["wiki-common:widget/lib/jquery/jquery"],function($){
            function openTagToggle(node) {
                if ($(node).hasClass("collapse")) {
                    $(node).removeClass("collapse");
                    $("#open-tag").css("height", '22px');
                } else {
                    $(node).addClass("collapse");
                    $("#open-tag").css("height", $("#open-tag-item").css("height"));
                }
            }
            if (parseInt($("#open-tag-item").css("height")) <= 30) {
                $('#open-tag-collapse').hide();
            }
            $("#open-tag-collapse").on("click", function () {
                openTagToggle($("#open-tag")[0]);
            });
        });
    }();
!function(){    var $ = require("wiki-common:widget/lib/jquery/jquery");
    
    var slider = {
        init: function() {
            this.control = $("#professional_control");
            this.prev = this.control.find(".J-prev");
            this.next = this.control.find(".J-next");
            this.el = $("#professional_list");
            this.view = this.el.find(".J-slider");
            this.items = this.view.find("ul");
            this.itemWidth = this.items.eq(0).innerWidth();
            this.initStatus();
            this.bindEvents();
        },
        initStatus: function() {
            this.view.css({
                width: this.items.length*this.itemWidth+"px",
                position: "absolute"
            });
            this.setHeight(0);
            if ( this.items.length < 2 ) return;
            this.changeControllers(0);
        },
        bindEvents: function() {
            var self = this, index = 0;
            if ( this.items.length < 2 ) return;
            this.next.on("click", function() {
                if ( self.items.length-1 === index ) return;
                index++;
                self.setHeight(index);
                self.goAni(index);
                self.changeControllers(index);
            });
            this.prev.on("click", function() {
                if ( index == 0 ) return;
                index--;
                self.setHeight(index);
                self.goAni(index);
                self.changeControllers(index);
            });
        },
        setHeight: function(index) {
            this.el.height( this.items.eq(index).innerHeight() );
        },
        goAni: function(index) {
            this.view.animate({
                left: index === 0 ? 0 : "-"+this.itemWidth*index+"px"
            });
        },
        changeControllers: function(index) {
            var disabledClass = "pro-control-disable";
            this.prev.removeClass(disabledClass);
            this.next.removeClass(disabledClass);
            if ( index === 0 ) {
                this.prev.addClass(disabledClass);
            } else if ( index === this.items.length-1 ) {
                this.next.addClass(disabledClass);
            }
        }
    };
    slider.init();
}();
!function(){        require('wiki-lemma:widget/lemma_content/configModule/zhixin/zhixin')(
            7385877,
            '变电站'
        );
    }();
!function(){    require.async(["wiki-lemma:widget/lemma_content/mainContent/lemmaStatistics/lemmaStatistics"],function(init){
        init({
            newLemmaIdEnc:"afa769b9e40ab541c9cfd790"
        });
    });
}();
!function(){	require.async(["wiki-lemma:widget/lemma_content/mainContent/sideCatalog/sideCatalog"],function(SideCatalog){
		new SideCatalog();
	});
}();
!function(){        require.async(["wiki-lemma:widget/promotion/fengchao/fengchao","wiki-lemma:widget/promotion/unionAd/unionAd"], function (init, unionAd) {
            init({
                newLemmaId: "7385877",
                lemmaTitle: "变电站",
                encodeLemmaTitle: "%B1%E4%B5%E7%D5%BE",
                adManager: {"wapRelatedBusiness":1}
            }, {
                errFn: unionAd,
                dom: $('#side_box_unionAd')
            });
        });
    }();
!function(){        require.async(['wiki-lemma:widget/promotion/guessLike/guessLike'], function (app) {
            app.init({
                lemmaTitle: '变电站',
                adManager: {"wapRelatedBusiness":1}
            });
        });
    }();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var Dialog = require("wiki-common:widget/ui/dialog/dialog");
    var userLogin = require('wiki-common:widget/component/userLogin/userLogin');
    var unameFiller = require('wiki-common:widget/component/unameFiller/unameFiller');
    var rightCheck = require('wiki-lemma:widget/tools/rightCheck/rightCheck');
    var nsLog = require('wiki-common:widget/component/nslog/nslog');

            var isEnterprise = false;
        var enterpriseOwnerUserId = 0;
    
    var userId = 0;
    var editUrl = '/edit/' + encodeURIComponent('变电站') + '/' + '7385877';
    var pgcUrl = '/enterprise/editpgc?lemmaId=7385877';
    var canDiscussion = $('.j-discussion-link').length > 0 ? true : false;

    userLogin.regist({
        onLogin: function(user) {
            userId = user ? user.uid : 0;
        }
    });

    function gotoEdit(url, isMidNight) {
        if (isMidNight) {
            Dialog.alert({
                title: '编辑提示',
                subMsg: '晚23:00至次日8:00，因审核系统例行维护，您提交的版本可能需要较长时间才能通过，望您谅解。',
                onConfirm: function() {
                    window.location.href = url;
                }
            });
        } else {
            window.location.href = url;
        }    
    }

    function showChoseEditDialog(pgcCallback, ugcCallback) {
        new Dialog({
            title: '编辑提示',
            subMsg: '<p>您已开通企业百科服务，推荐您直接编辑“官方资料”，官方资料仅限企业百科绑定的百科账号修改，其他用户账号不可修改。</p><p>如果您想修改其他网友编辑的普通词条内容，请注意遵守百科百科编辑规则。<p>',
            btns: [{
            key: 'pgc',
            text: '编辑官方资料'
            }, {
            style: 'white',
            text: '修改普通词条',
            key: 'ugc'
            }],
            onBtnClick: function(btnKey){
                if (btnKey === 'pgc') {
                    pgcCallback && pgcCallback();
                } else if (btnKey === 'ugc') {
                    ugcCallback && ugcCallback();
                }
            }
        }).show();
    }

    function checkUserLegal(res) {
        var legal = false;
        switch (res.errno) {
            case 100001:
                nsLog('10003106');
                userLogin.showLoginPop();
                break;
            case 100006:
                unameFiller.show();
                break;
            default:
                legal = true;
        }
        return true;
    }

    function checkUgc(res, url) {
        if (res.errno) {
            switch (res.errno) {
                case 100005:
                    alert('对不起，您目前被封禁');
                    break;
                case 110001:
                    alert('对不起，该词条被锁定');
                    break;
                case 110007:
                    alert('对不起，消歧页无法编辑');
                    break;
                case 110005:
                    nsLog('10003101');
                    var content = '<div style="text-align: left;width: 490px">'
                        + '<h2 style="font-size: 20px;color: #333;line-height: 26px;margin-top: 10px;margin-bottom: 20px;">' 
                        + '对不起，你暂时没有权限编辑该词条</h2>' 
                        + '<p style="font-size: 16px;color: #333;line-height: 26px;margin-bottom: 17px;">'
                        + '亲爱的用户，该词条内容已较完善，需百科等级达到4级且通过率达85%才可编辑哦。</p>'
                        + '<p style="font-size: 16px;color: #333">你当前百科等级为'
                        + res.data.userInfo.level + '级、通过率'
                        + res.data.userInfo.passRatio + '%，可进行以下操作：</p></div>';
                    var btns = [
                        {
                            key: 'join',
                            text: '<span style="font-size: 14px;text-align: center;vertical-align: middle;display: table-cell;">反馈词条问题，参与百科共建</span>'
                        },
                        {
                            text: '<span style="font-size: 14px;text-align: center;vertical-align: middle;display: table-cell;">参加成长任务，提升编辑权限</span>',
                            key: 'task'
                        }
                    ];
                    if (canDiscussion) {
                        btns = [
                            {
                                key: 'discussion',
                                text: '<span style="font-size: 14px">参与词条讨论，反馈词条问题</span>'
                            },
                            {
                                text: '<span style="font-size: 14px">参加成长任务，提升编辑权限</span>',
                                key: 'task'
                            }
                        ];
                    }
                    new Dialog({
                        title: '编辑提示',
                        content: content,
                        btns: btns,
                        onBtnClick: function(btnKey){
                            if (btnKey === 'discussion') {
                                window.location.href = '/planet/talk?lemmaId=7385877&category=1';
                            } else if (btnKey === 'task') {
                                window.location.href = '/usercenter#guide';
                            } else if (btnKey === 'join') {
                                window.location.href = '/feedback';
                            }
                        }
                    }).show();
                    break;
                case 110008:
                    nsLog('10003102');
                    var content = '<div style="text-align: left;width: 490px">'
                        + '<h2 style="font-size: 20px;color: #333;line-height: 26px;margin-bottom: 20px;margin-top: 10px;">' 
                        + '对不起，你暂时没有权限编辑该词条</h2>' 
                        + '<p style="font-size: 16px;color: #333;line-height: 26px;margin-bottom: 17px;">'
                        + '亲爱的用户，该词条内容已较完善，需百科等级达到6级且通过率达85%才可编辑哦。</p>'
                        + '<p style="font-size: 16px;color: #333">你当前百科等级为'
                        + res.data.userInfo.level + '级、通过率'
                        + res.data.userInfo.passRatio + '%，可进行以下操作：</p></div>';
                    var btns = [
                        {
                            key: 'join',
                            text: '<span style="font-size: 14px;text-align: center;vertical-align: middle;display: table-cell;">反馈词条问题，参与百科共建</span>'
                        },
                        {
                            text: '<span style="font-size: 14px;text-align: center;vertical-align: middle;display: table-cell;">参加成长任务，提升编辑权限</span>',
                            key: 'task'
                        }
                    ];
                    if (canDiscussion) {
                        btns = [
                            {
                                key: 'discussion',
                                text: '<span style="font-size: 14px">参与词条讨论，反馈词条问题</span>'
                            },
                            {
                                text: '<span style="font-size: 14px">参加成长任务，提升编辑权限</span>',
                                key: 'task'
                            }
                        ];
                    }
                    new Dialog({
                        title: '编辑提示',
                        content: content,
                        btns: btns,
                        onBtnClick: function(btnKey){
                            if (btnKey === 'discussion') {
                                window.location.href = '/planet/talk?lemmaId=7385877&category=1';
                            } else if (btnKey === 'task') {
                                window.location.href = '/usercenter#guide';
                            } else if (btnKey === 'join') {
                                window.location.href = '/feedback';
                            }
                        }
                    }).show();
                    break;
                case 470001:
                    alert('系统错误，请刷新重试');
                    break;
                case 110003:
                    nsLog('10003103');
                    Dialog.alert({
                        title: '编辑提示',
                        subMsg: '很抱歉，该词条有其他用户编辑的版本正在提交，您暂时无法编辑。<br/>百科建议您晚些时候再编辑该词条，或者尝试编辑其他的词条。'
                    });
                    break;
            }
        } else {
            if (!res.data.right.noAudit) {
                Dialog.alert({
                    title: '编辑提示',
                    subMsg: '很抱歉，该词条有其他用户编辑的版本正在提交，您暂时无法编辑。<br/>百科建议您晚些时候再编辑该词条，或者尝试编辑其他的词条。'
                });
                return;
            }
            gotoEdit(url, res.data.notice.isMidNight);
        }
    }

    $(document.body).on('click', '.j-edit-link', function() {
        nsLog('10003100');
        var dl = $(this).attr('data-edit-dl');
        if (dl) {
            var url = editUrl + '?dl=' + dl;
        } else {
            var url = editUrl;
        }

        rightCheck.preeditCheck('7385877', '变电站', '变电站', '136112321', '', function(res) {
            if (!checkUserLegal(res)) {
                return;
            }
            if (isEnterprise && enterpriseOwnerUserId === userId) {
                showChoseEditDialog(function() {
                    location.href = pgcUrl;
                }, function() {
                    checkUgc(res, url);
                });
            } else {
                checkUgc(res, url);
            }
        });
    });
}();
!function(){  require.async(["wiki-common:widget/lib/jquery/jquery","wiki-common:widget/component/footer/footer_feedback"], function($, feedback){
    feedback({el: '#J-bk-feedback-main',
      proData: {
        "extend_feedback_channel": 33430
      }
    });
    feedback({el: '#J-bk-feedback-query', config: {
        appid: 215645,
        productLine: 20184,
        needContactWay: false,
        issuePlaceholder: '亲爱的百度百科用户，请在此填写您的质疑内容及原因哦～'
      },
      proData: {
        "kw": $('#J-bk-feedback-query').data('lemma')
      }
    });
  });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery'),
      initSearchbar = require('wiki-common:widget/component/searchbar-n/searchbar');  
    initSearchbar($('.wgt-searchbar-simple'));
  }();
!function(){    require.async(["wiki-lemma:widget/tools/searchHeader/toolButtons-n/toolButtons"],function(init){
        init({
            lemmaId:"406127",
            subLemmaId:"406127",
            newLemmaId:"7385877"
        });
    });
}();
!function(){    require('wiki-lemma:widget/tools/searchHeader/toolButtons-n/userInfo')();
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery'),
      animation = require('wiki-common:widget/util/animation'),
      nslog = require('wiki-common:widget/component/nslog/nslog'),
      initSearchbar = require('wiki-common:widget/component/searchbar/searchbar');

    var isFadeIn = false,
        isFadeOut = false;

    var fadeInAni, fadeOutAni;

    $(window).on('scroll', function(e) {
        var scrollTop = $(this).scrollTop();

        if (scrollTop > 200 && !isFadeIn && $('.lemmaWgt-searchHeader').css('display') == 'none') {
            fadeOutAni && fadeOutAni.stop();
            fadeInAni = animation({
                duration: 200,
                easing: 'linear',
                onStart: function() {
                    isFadeOut = false;
                    isFadeIn = true;
                    $('.lemmaWgt-searchHeader').css('display', 'block');
                },
                onStep: function(progress) {
                    $('.lemmaWgt-searchHeader').css('opacity', progress)
                },
                onComplete: function(progress) {
                    isFadeIn = false;
                    nslog(10010007);
                }
            });
        } else if (scrollTop <= 200 && !isFadeOut && $('.lemmaWgt-searchHeader').css('display') == 'block') {
            fadeInAni && fadeInAni.stop();
            fadeOutAni = animation({
                duration: 300,
                easing: 'linear',
                onStart: function() {
                    $('.lemmaWgt-searchHeader #suggestion').hide();
                    isFadeIn = false;
                    isFadeOut = true;
                },
                onStep: function(progress) {
                    $('.lemmaWgt-searchHeader').css('opacity', 1 - progress);
                },
                onComplete: function(progress) {
                    isFadeOut = false;
                    $('.lemmaWgt-searchHeader').css('display', 'none');
                }
            });
        }
    });
}();
!function(){    require.async(['wiki-lemma:widget/tools/newSideShare/qzopensl']);
    require.async(["wiki-lemma:widget/tools/newSideShare/taskSideShare"],function(taskShare){
        taskShare.init({
            title: '变电站',
            desc: "\u53d8\u7535\u7ad9\u662f\u6307\u7535\u529b\u7cfb\u7edf\u4e2d\u5bf9\u7535\u538b\u548c\u7535\u6d41\u8fdb\u884c\u53d8\u6362\uff0c\u63a5\u53d7\u7535\u80fd\u53ca\u5206\u914d\u7535\u80fd\u7684\u573a\u6240\u3002\u5728\u53d1\u7535\u5382\u5185\u7684\u53d8\u7535\u7ad9\u662f\u5347\u538b\u53d8\u7535\u7ad9\uff0c\u5176\u4f5c\u7528\u662f\u5c06\u53d1\u7535\u673a\u53d1\u51fa\u7684\u7535\u80fd\u5347\u538b\u540e\u9988\u9001\u5230\u9ad8\u538b\u7535\u7f51\u4e2d\u3002",
            pic: 'https:\/\/gss1.bdstatic.com\/-vo3dSag_xI4khGkpoWK1HF6hhy\/baike\/w%3D268\/sign=71c90af90ae9390156028a3843ed54f9\/35a85edf8db1cb1344448ecad654564e92584b3d.jpg',
            url: '',
            qqPic: 'https:\/\/gss1.bdstatic.com\/-vo3dSag_xI4khGkpoWK1HF6hhy\/baike\/whfpf%3D400%2C400%2C50\/sign=ebddfc6095510fb3784c24d7bf0efca5\/35a85edf8db1cb1344448ecad654564e92584b3d.jpg',
            newLemmaId: '7385877',
            lemmaTitle: '变电站'
        });
    });
}();
!function(){    var $ = require('wiki-common:widget/lib/jquery/jquery');
    var nslog = require("wiki-common:widget/component/nslog/nslog");
    var testElem = require('wiki-common:widget/component/testElem/testElem');
    var cmsModuleLoader = require('wiki-common:widget/component/cmsModuleLoader/cmsModuleLoader');

    function requireAsync() {
        require.async(['wiki-lemma:widget/tools/announcement/announcement']);
    }

    cmsModuleLoader('/api/wikiui/getlemmaconfig', [{
        name: 'announcement',
        script: 'wiki-lemma:widget/tools/announcement/announcement.js'
    }]);

    require.async(["wiki-lemma:widget/tools/lazyLoad/lazyLoad"], function(LazyLoad) {
        new LazyLoad();
    });

    require.async(['wiki-common:widget/component/nslog/nslog','wiki-common:widget/lib/jquery/jquery'], function(nslog, $) {
        nslog().setGlobal({
            lemmaId: "406127",
            newLemmaId: "7385877",
            subLemmaId: "406127",
            lemmaTitle: "变电站"
        });

        // 词条页 pv
        nslog(9322);

        // 新版头部pv（小流量）
        if ($('.pc-header-new').length > 0) {
            nslog(9069);
        }

        // 链接点击 pv
        var lemmaPageRegExp = new RegExp(/\/subview\/\d+|\/view\/\d+|\/item\//i);
        $('body').on('mousedown', 'a', function() {
            var href = $(this).attr('href');
            if (href && href.indexOf('/') >= 0 && href.indexOf('#') !== 0) {
                // 链接点击 pv
                nslog(10000001);
                if (lemmaPageRegExp.test(href)) {
                    // 词条页链接点击 pv
                    nslog(10000002, window.location.href, {
                        targetTitle: $(this).text()
                    });
                }
            }
        });

        /****** 词条页站内流转需求统计 start ******/
        (function () {
            // 各种统计配置
            var circulationLinkCfg = {
                innerLink: [ // 内链
                    '.para',
                    '.lemmaWgt-baseInfo-simple-largeMovie',
                    '.lemmaWgt-baseInfo-simple-largeStar',
                    '.basic-info .basicInfo-block',
                    '.lemma-summary',
                    '.lemmaWgt-lemmaSummary',
                    '.view-tip-panel',
                    '.horizontal-module',
                    '.lemmaWgt-roleIntroduction',
                    '.dramaSeries .dramaSerialList',
                    '.module-music',
                    '.table-view',
                    '[log-set-param="table_view"]',
                    '.list-module',
                    '.cell-module',
                    '.baseBox .dl-baseinfo', // 配置后台字段
                    '.pvBtn-box .leadPVBtnWrapper',
                    '.drama-actor',
                    '#staffList',
                    '.starMovieAndTvplay',
                    '.main_tab:not(.main_tab-defaultTab)' // 除去词条tab外的tab
                ],
                relationTable: '.rs-container-foot', // 关系表
                peopleRelation: '.star-info-block.relations, .lemmaWgt-focusAndRelation', // 人物关系（明星+普通）
                moduleActors: '.featureBaseInfo .actors, .lemmaWgt-majorActors', // 主要演员、嘉宾、主持人
                moduleWorks: '.featureBaseInfo .works, .large-feature .works', // 代表作品
                moduleQuarterly: '.featureBaseInfo .po_quarterly, .mian_quarterly', // 分季介绍
                rankStar: '.rank-list.stars-rank', // 明星榜
                rankDrama: '.drama-rank-list', // 电视剧榜
                specialTopic: '.special-topic', // 专题模块
                modDetailTable: '#modDetailTable', // 关系表出图
                chuizhitu: '.chuizhitu', // 垂直化模块
                polysemantList: '.polysemantList-wrapper' // 义项切换
            };
            /****** 连接统计 ******/
            function clickNslogFn() {
                for (var k in circulationLinkCfg) {
                    if (k === 'innerLink') {
                        // 词条内链到词条页
                        var tempArr = circulationLinkCfg[k];
                        for (var i = 0, l = tempArr.length; i < l; i++) {
                            tempArr[i] += ' a';
                        }
                        var sSelector = tempArr.join(', ');

                        $('body').on('mousedown', sSelector, {key: k},function(e) {
                            var key = e.data.key;
                            var href = $(this).attr('href');
                            var tar = $(this).attr('target') || '';
                            if (href && href.indexOf('/') >= 0 && href.indexOf('#') !== 0
                            && tar === '_blank' && lemmaPageRegExp.test(href)) {
                                // 词条页普通内链点击 pv
                                nslog(10000004, null ,{division: key});
                            }
                        });
                    } else {
                        // 模块到词条页链接
                        $(circulationLinkCfg[k]).on('mousedown', 'a', {key: k}, function (e) {
                            var key = e.data.key;
                            var href = $(this).attr('href');
                            if (href && href.indexOf('#') !== 0 && lemmaPageRegExp.test(href)) {
                                // 词条页配置模块链接点击 pv
                                nslog(10000004, null, {division: key});
                            }
                        });
                    }
                }
            }
            // 发起统计请求
            clickNslogFn();

            /****** 各模块展现量pv ******/
            function checkModuleIsShow() {
                var result = [];
                for (var k in circulationLinkCfg) {
                    if (k !== 'innerLink' && k !== 'relationTable') {
                        !!$(circulationLinkCfg[k]).html() && result.push(k);
                    }
                }
                if (result.length > 0) {
                    nslog(10000005, null, {showModules: result.join(',')});
                }
            }
            checkModuleIsShow();

        })();
        /****** 词条页站内流转需求统计 end ******/

    });

    // 广告接入 wikiad 统一加载
    // log 词条页广告被拦截情况（此处 log 请求行为）
    nslog(70000101, window.location.href, {
        api: 'lemma-ad',
        action: 'request'
    });
    var tags = {"1":{"tagId":76600,"tagName":"\u79d1\u5b66\u767e\u79d1\u5de5\u7a0b\u6280\u672f\u5206\u7c7b"},"0":{"tagId":0,"tagName":"\u793e\u4f1a"}};
    var tagsArray = [];
    for (var key in tags) {
        tagsArray.push(tags[key].tagName);
    }
    $.ajax({
        type: 'GET',
        url: '/api/wikiad/getsquirrels',
        data: {
            lemmaId: 7385877,
            tags: tagsArray.join()
        },
        cache: false,
        dataType: 'JSON',
        success: function (res) {
            // log 词条页广告被拦截情况（此处 log 请求成功）
            nslog(70000101, window.location.href, {
                api: 'lemma-ad',
                action: 'success'
            });

            if (!res.errno) {
                if (res.data[5]) {
                    require.async(['wiki-lemma:widget/promotion/rightPreciseAd/rightPreciseAd'], function(rightPreciseAd) {
                        rightPreciseAd(res.data[5]);
                        nslog(10002201, location.href, {
                            adId: res.data[5][0].adId,
                            adTitle: res.data[5][0].name,
                            adPos: 5
                        });
                    });
                } else if (res.data[1]) {
                                        require.async(['wiki-lemma:widget/promotion/vbaike/vbaike'], function(vbaike) {
                        vbaike(res.data[1]);
                        for(var i in res.data[1]) {
                            nslog(10002201, location.href, {
                                adId: res.data[1][i].adId,
                                adTitle: res.data[1][i].name,
                                adPos: 1
                            });
                        }
                    });
                                    }
                if (res.data[9]) {
                                        require.async(['wiki-lemma:widget/promotion/rightBigAd/rightBigAd'], function(rightBigAd) {
                        rightBigAd(res.data[9]);
                            nslog(10002201, location.href, {
                                adId: res.data[9][0].adId,
                                adTitle: res.data[9][0].name,
                                adPos: 9
                            });
                    });
                                    } else if(res.data[2]) {
                    require.async(['wiki-lemma:widget/promotion/slide/slide'], function(slide) {
                        slide(res.data[2]);
                        for(var i in res.data[2]) {
                            nslog(10002201, location.href, {
                                adId: res.data[2][i].adId,
                                adTitle: res.data[2][i].name,
                                adPos: 2
                            });
                        }
                    });
                }
                if (res.data[3]) {
                                        require.async(['wiki-lemma:widget/promotion/topAd/topAd'], function(topAd) {
                        topAd(res.data[3]);
                        nslog(10002201, location.href, {
                            adId: res.data[3][0].adId,
                            adTitle: res.data[3][0].name,
                            adPos: 3
                        });
                    });
                                    }
                if (res.data[4]) {
                                        require.async(['wiki-lemma:widget/promotion/rightAd/rightAd'], function(rightAd) {
                        rightAd(res.data[4]);
                        nslog(10002201, location.href, {
                            adId: res.data[4][0].adId,
                            adTitle: res.data[4][0].name,
                            adPos: 4
                        });
                    });
                                    }
                if (res.data[15]) {
                    require.async(['wiki-lemma:widget/promotion/banner/banner'], function(banner) {
                        banner(res.data[15]);
                        nslog(10002201, location.href, {
                            adId: res.data[15][0].adId,
                            adTitle: res.data[15][0].name,
                            adPos: 15
                        });
                    });
                }
                if (res.data[16]) {
                    require.async(['wiki-lemma:widget/promotion/declaration/declaration'], function(declaration) {
                        declaration(res.data[16]);
                        nslog(10002201, location.href, {
                            adId: res.data[16][0].adId,
                            adTitle: res.data[16][0].name,
                            adPos: 16
                        });
                    })
                }
            } else {
                return;
            }

            setTimeout(function () {
                var elemArr = {};
                res.data[1] && res.data[1].length > 0 && (elemArr['lemma-vbaike-ad'] = $('.lemmaWgt-promotion-vbaike .promotion_viewport a:eq(0) img').get(0));
                res.data[2] && res.data[2].length > 0 && (elemArr['lemma-slide-ad'] = $('.lemmaWgt-promotion-slide .promotion_viewport a:eq(0) img').get(0));
                res.data[3] && res.data[3].length > 0 && (elemArr['lemma-navbar-ad'] = {
                    node: $('.header [nslog-type="10002202"]').get(0),
                    validations: {
                        'noBackgroundImage': function() {
                            return $('.header [nslog-type="10002202"]').css('background-image').indexOf(res.data[3][0].picUrl) < 0
                        }
                    }
                });
                res.data[4] && res.data[4].length > 0 && (elemArr['lemma-side-ad'] = {
                    node: $('.right-ad img').get(0),
                    validations: {
                        'noBackgroundImage': function() {
                            return $('.right-ad img').attr('src').indexOf(res.data[4][0].picUrl) < 0
                        }
                    }
                });
                res.data[15] && res.data[15].length > 0 && (elemArr['lemma-configModule-banner'] = $('.configModuleBanner').get(0));
                res.data[16] && res.data[16].length > 0 && (elemArr['lemma-configModule-declaration'] = $('.lemmaWgt-declaration').get(0));

                testElem.log(elemArr, 70000102);
            }, 1000);
        },
        error: function () {
            // log 词条页广告被拦截情况（此处 log 请求失败）
            nslog(70000101, window.location.href, {
                api: 'lemma-ad',
                action: 'error'
            });
        }
    });

    // 设置分享内容
    window.BKShare.setCommon({
        bdText: "\u3010\u53d8\u7535\u7ad9_\u767e\u5ea6\u767e\u79d1\u3011\u53d8\u7535\u7ad9\u662f\u6307\u7535\u529b\u7cfb\u7edf\u4e2d\u5bf9\u7535\u538b\u548c\u7535\u6d41\u8fdb\u884c\u53d8\u6362\uff0c\u63a5\u53d7\u7535\u80fd\u53ca\u5206\u914d\u7535\u80fd\u7684\u573a\u6240\u3002\u5728\u53d1\u7535\u5382\u5185\u7684\u53d8\u7535\u7ad9\u662f\u5347\u538b\u53d8\u7535\u7ad9\uff0c\u5176\u4f5c\u7528\u662f\u5c06\u53d1\u7535\u673a\u53d1\u51fa\u7684\u7535\u80fd\u5347\u538b\u540e\u9988\u9001\u5230\u9ad8\u538b\u7535\u7f51\u4e2d\u3002.....\uff08\u5206\u4eab\u81ea@\u767e\u5ea6\u767e\u79d1\uff09",
        bdDesc: '',
        bdUrl: 'http:\/\/baike.baidu.com\/item\/%E5%8F%98%E7%94%B5%E7%AB%99\/7385877',
        bdPic: '',
        onBeforeClick: function (){
            $('.bdshare_dialog_box').hide();
        }
    });

    // 底部投诉带入当前页面 url
    var map = [1, 2, 6, 5];
    $('.wgt-footer-main .suggestion').find('a').each(function(i) {
        $(this).attr('href', 'http://help.baidu.com/newadd?word=%E5%8F%98%E7%94%B5%E7%AB%99' + '&&submit_link=' + encodeURIComponent(window.location.href) + '&prod_id=10&category=' + map[i]);
    });

    // 为超出预设内容的表格添加table-responsive控制
    $('.main-content').find('table').each(function(index) {
        var $that = $(this);
        if ($that.width() > 790) {
            $that.wrap('<div class="table-responsive"></div>');
        }
    });
}();
!function(){      require('wiki-common:widget/component/psLink/psLink');
    }();</script>
<script type="text/javascript">
  var Hunter = window.Hunter || {};
  Hunter.userConfig = Hunter.userConfig || [];
  </script>
<script type="text/javascript" src="https://gss0.baidu.com/70cFsjip0QIZ8tyhnq/hunter/baike.js?st=18058" defer></script><script type="text/javascript">
  // DOM Ready时，统计用户可操作时间。
  alog('speed.set', 'drt', +new Date);

  void function(a,b,c,d,e,f){function g(b){a.attachEvent?a.attachEvent("onload",b,!1):a.addEventListener&&a.addEventListener("load",b)}function h(a,c,d){d=d||15;var e=new Date;e.setTime((new Date).getTime()+1e3*d),b.cookie=a+"="+escape(c)+";path=/;expires="+e.toGMTString()}function i(a){var c=b.cookie.match(new RegExp("(^| )"+a+"=([^;]*)(;|$)"));return null!=c?unescape(c[2]):null}function j(){var a=i("PMS_JT");if(a){h("PMS_JT","",-1);try{a=a.match(/{["']s["']:(\d+),["']r["']:["']([\s\S]+)["']}/),a=a&&a[1]&&a[2]?{s:parseInt(a[1]),r:a[2]}:{}}catch(c){a={}}a.r&&b.referrer.replace(/#.*/,"")!=a.r||alog("speed.set","wt",a.s)}}if(a.alogObjectConfig){var k=a.alogObjectConfig.sample,l=a.alogObjectConfig.rand;d="https:"===a.location.protocol?"https://fex.bdstatic.com"+d:"http://fex.bdstatic.com"+d,k&&l&&l>k||(g(function(){alog("speed.set","lt",+new Date),e=b.createElement(c),e.async=!0,e.src=d+"?v="+~(new Date/864e5)+~(new Date/864e5),f=b.getElementsByTagName(c)[0],f.parentNode.insertBefore(e,f)}),j())}}(window,document,"script","/hunter/alog/dp.min.js");
</script>
</html>

'''
###########################################################
# Url:http://guba.eastmoney.com/list,600051.html
# Referer:http://quote.eastmoney.com/sh600051.html
# Url:http://guba.eastmoney.com/list,000809.html
# Referer:http://quote.eastmoney.com/sz000809.html
# Url:http://guba.eastmoney.com/list,hk00142.html
# Referer:http://quote.eastmoney.com/hk/00142.html
###########################################################
# http://guba.eastmoney.com/list,600051_2.html
# Referer:http://guba.eastmoney.com/list,600051.html
###########################################################
# http://guba.eastmoney.com/list,600051_3.html
# Referer:http://guba.eastmoney.com/list,600051_2.html



'''
class Class_Http_Get_Read_Guba_Eastmoney():


	def __Prase_articleh_Info(self,articleh_Info):
		# 港股无视emqa，即这里返回emqa==False
		#### print '阅读\t评论\t标题\t作者\t发表日期\t最后更新'
		try:
			shorturl = str(articleh_Info.xpath( './/span[@class="l3"]/a/@href' )[ 0 ])  # link
			if (self.__In_Guba( shorturl )):
				read = int( articleh_Info.xpath( './/span[@class="l1"]/text()' )[ 0 ] )  # 阅读
				comment = int( articleh_Info.xpath( './/span[@class="l2"]/text()' )[ 0 ] )  # 评论
				pub = str(articleh_Info.xpath( './/span[@class="l6"]/text()' )[ 0 ])  # 发表日期
				update = str(articleh_Info.xpath( './/span[@class="l5"]/text()' )[ 0 ])  # 最后更新
				try:
					# emtext = articleh_Info.xpath('.//span[@class="l3"]/em[@class="qa"]/a/text()')[0]  # 问董秘
					# emtext = articleh_Info.xpath( './/span[@class="l3"]/em[@class="qa"]/a/text()' )[ 0 ]  # 问董秘
					# emtext = articleh_Info.xpath('.//span[@class="l3"]/em[@class="hinfo"]/text()')[0]  # 新闻
					em = articleh_Info.xpath('.//span[@class="l3"]/em')  # 问董秘+新闻+公告
					if(0==len(em)):
						emqa = False
					else:
						emqa = True
				except:
					emqa = False
				finally:
					if('HK'==self.__read.get('exchange')):
						emqa = False
					return ( True, {"read":read, "comment":comment, "pub":pub, "update":update, "shorturl":shorturl, "emqa":emqa })
		except:
			pass
		return(False,{})




	def __Print_Page(self,html_str):
		#解析一个页面，'阅读\t评论\t标题\t作者\t发表日期\t最后更新'
		selector = etree.HTML( html_str )
		try:
			articleh = selector.xpath( '//div[@class="articleh"]' )
			#### print '阅读\t评论\t标题\t作者\t发表日期\t最后更新'
			print "Total:",len(articleh)
			for ainfo in articleh:
				try:
					shorturl = ainfo.xpath( './/span[@class="l3"]/a/@href' )[ 0 ]  # link
					#if (self.__In_Guba( shorturl )):
					print ainfo.xpath( './/span[@class="l6"]/text()' )[ 0 ],  # 发表日期
					print ainfo.xpath( './/span[@class="l5"]/text()' )[ 0 ],  # 最后更新
					print self.__In_Guba( ainfo.xpath( './/span[@class="l3"]/a/@href' )[ 0 ] ),
					print ainfo.xpath( './/span[@class="l1"]/text()' )[ 0 ],  # 阅读
					print ainfo.xpath( './/span[@class="l2"]/text()' )[ 0 ],  # 评论
					print ainfo.xpath( './/span[@class="l3"]/a/@href' )[ 0 ]  # link
					# print ainfo.xpath( './/span[@class="l3"]/a/text()' )[ 0 ],		#标题
					#print ainfo.xpath( './/span[@class="l4"]/a/text()' )[ 0 ]  # 作者

				except:
					pass
		except:
			pass
'''

def Baidu_Baike_Declaration0(sHtml_Str):
    #解析百度百科页面，返回条目的定义项，String
    selector = etree.HTML( sHtml_Str )
    sRet = ''
    try:
        articleh = selector.xpath( '//div[@class="para"]' )[0]
        if(articleh):
            aString = articleh.xpath('.//text()')
            sRet = ''.join(aString)
    except:
        pass
    return sRet

def Baidu_Baike_Declaration(sHtml_Str):
    #解析百度百科页面，返回条目的定义项，String
    selector = etree.HTML( sHtml_Str )
    sRet = ''
    try:
        articleh = selector.xpath( '//div[@class="para"]' )
        if(articleh):
            aString = articleh[0].xpath('.//text()')
            sRet = ''.join(aString)
    except:
        pass
    return sRet

s = Baidu_Baike_Declaration(html_str)
print(s)
s = Baidu_Baike_Declaration0(html_str)
print(s)
#st =Class_Get_Guba_Save_To_ReadDaily('600051')
#st.Load_Read_From_ReadDaily_Class()
#print st.Run()
#print st.Get_Read()
