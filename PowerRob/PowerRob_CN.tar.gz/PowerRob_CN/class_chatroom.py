# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports


###################### Class Define #######################
class Class_Chatroom():
	# 处理 Chatroom Class的存取

	def chatroom(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		#query.limit(10)  # 最多返回 LIMIT_QUERY 条结果
		query.equal_to('Active', True)
		#self.aQuestion = []
		aFind = query.find()  # 查找descending
		aChatroom = []
		for item in aFind:
			aChatroom.append({'NickName':item.get('NickName'),'Alert':item.get('Alert')})
		return aChatroom

	############## private #####
	def __init__(self):
		self.__DBClassName = "Chatroom"
		#self.aQuestion = []

##########################Do not delete############################
#CHATROOM_CLASS = Class_Chatroom()
