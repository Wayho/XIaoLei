# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
# Standard library imports


###################### Class Define #######################
class Class_Question():
	# 处理 Question Class的存取

	def Add(self, oQuestion):
		DBClass = leancloud.Object.extend( self.__DBClassName )
		dB = DBClass()
		dB.set('From', oQuestion.get('From'))
		dB.set('Question', oQuestion.get('Question'))
		dB.set('Active', True )
		dB.save()
		return dB.id

	def Delete(self, sQuestion):
		DBClass = leancloud.Object.extend( self.__DBClassName )
		query = DBClass.query
		query.equal_to('Question', sQuestion)
		try:
			oAnswer = query.first()
			todo = DBClass.create_without_data(oAnswer.get('objectId'))
			todo.set('Active', False)
			todo.save()
			return True
		except:
			return False

	def All10(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		query.limit(10)  # 最多返回 LIMIT_QUERY 条结果
		query.equal_to('Active', True)
		#self.aQuestion = []
		aFind = query.find()  # 查找descending
		sMsg = '以下是群友提出的问题：'
		for item in aFind:
			sMsg += '\n' + item.get('Question')
		return sMsg

	############## private #####
	def __init__(self):
		self.__DBClassName = "Question"
		#self.aQuestion = []

##########################Do not delete############################
QUESTION_CLASS = Class_Question()
