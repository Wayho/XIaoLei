#!/usr/bin/env python3
# coding: utf-8

import os
from power_keywords import PowerKeywords
hPowerKeywords = PowerKeywords()

class YmlFile:
    def __init__(self):
        cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
        #　answer路径
        self.method_path = os.path.join(cur_dir, 'dict/method.yml')
        # 加载answer
        self.source= [i.strip() for i in open(self.method_path) if i.strip()]
        self.length = len(self.source)
        self.branch_index = []
        self.answer_range = []
        self.answer = []
        self.__construct_answer()
        return

    def __construct_answer(self):
        #self.find_branch_index(0)
        self.__calc_answer_range()
        index = 0
        offset = 0  #self.answer中的位置
        sLast = ''
        for aRange in self.answer_range:
            if(sLast != self.source[aRange[2]][1:]):
                index = 0
            sAnswer = self.source[aRange[0]][1:]
            for iOffset in range(aRange[0]+1,aRange[1]):
                sAnswer += '\n' +self.source[iOffset]
            sRegion = self.source[aRange[2]][1:]
            #if (-1 == sAnswer.find(sRegion)):
            #    # 默认sAnswer必须包含sRegion
            #    sAnswer = sRegion + sAnswer
            aKeywords = hPowerKeywords.check_keywords(sAnswer)
            sKeywords = ''.join(aKeywords)
            self.answer.append(
                {'Index': index, 'Region': sRegion, 'Keywords': sKeywords, 'Answer': sAnswer})
                #{'Offset':offset, 'Index': index, 'Region': sRegion, 'Answer': sAnswer})
            sLast = self.source[aRange[2]][1:]
            index += 1
            offset += 1
        return len(self.answer)

    # branch的开始offset
    def find_branch_index(self, iOffset):
        if(iOffset<self.length):
            if('+'==self.source[iOffset][0]):
                self.branch_index.append(iOffset)
            self.find_branch_index(iOffset+1)
        return

    # answer的开始和结束offset
    def __calc_answer_range(self):
        iOffset = 0
        while (iOffset < self.length - 1):
            if('+'==self.source[iOffset][0]):
                iBranch = iOffset
            if ('-' == self.source[iOffset][0]):
                iStart = iOffset
                iOffset += 1
                while (iOffset < self.length - 1):
                    if (('-' == self.source[iOffset][0]) or ('+' == self.source[iOffset][0])):
                        break
                    else:
                        iOffset += 1
                self.answer_range.append([iStart, iOffset, iBranch])
            else:
                iOffset += 1
        # print(self.answer_range)
        return

    # answer的开始offset
    def find_answer_index(self, iOffset):
        if(iOffset<self.length):
            if('-'==self.source[iOffset][0]):
                self.answer_index.append(iOffset)
            self.find_answer_index(iOffset+1)
        return

    # answer的开始和结束offset
    def calc_answer_range2(self):
        for i in range(0,len(self.answer_index)):
            if(i<len(self.answer_index)-1):
                self.answer_range.append([self.answer_index[i],self.answer_index[i+1]])
            else:
                self.answer_range.append([self.answer_index[i], self.length])
        return

    def print_self(self):
        for answer in self.answer:
            print(answer)


if __name__ == '__main__':
    handler = YmlFile()
    handler.print_self()

