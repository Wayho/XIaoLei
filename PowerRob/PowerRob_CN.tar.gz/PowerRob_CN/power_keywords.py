#!/usr/bin/env python3
# coding: utf-8

import os
import ahocorasick

class PowerKeywords:
    def __init__(self):
        cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
        #　特征词路径
        self.equipment_path = os.path.join(cur_dir, 'dict/equipment.txt')
        self.concept_path = os.path.join(cur_dir, 'dict/concept.txt')
        self.work_path = os.path.join(cur_dir, 'dict/work.txt')
        # 加载特征词
        self.equipment_wds= [i.strip() for i in open(self.equipment_path) if i.strip()]
        self.concept_wds= [i.strip() for i in open(self.concept_path) if i.strip()]
        self.work_wds = [i.strip() for i in open(self.work_path) if i.strip()]
        self.region_words = set(self.equipment_wds+self.concept_wds+self.work_wds)
        # 构造领域actree
        self.region_tree = self.build_actree(list(self.region_words))

        self.userdict_path = os.path.join(cur_dir, 'dict/userdict.txt')
        self.userdict_wds = [i.strip() for i in open(self.userdict_path) if i.strip()]
        return

    # 构造actree，加速过滤
    def build_actree(self, wordlist):
        actree = ahocorasick.Automaton()
        for index, word in enumerate(wordlist):
            actree.add_word(word, (index, word))
        actree.make_automaton()
        return actree

    # 问句过滤，返回关键词组
    def check_keywords(self, question):
        region_wds = []
        for i in self.region_tree.iter(question):
            wd = i[1][1]
            #print(i)
            region_wds.append(wd)
        #print('region_wds', region_wds)
        stop_wds = []
        for wd1 in region_wds:
            for wd2 in region_wds:
                if wd1 in wd2 and wd1 != wd2:
                    stop_wds.append(wd1)
        final_wds = [i for i in region_wds if i not in stop_wds]
        #print(final_wds)
        return self.delete_duplicate(final_wds)

    # 删除重复项
    def delete_duplicate(self, aList):
        aRet = []
        for sItem in aList:
            if (not self.in_list(aRet, sItem)):
                aRet.append(sItem)
        return aRet

    # 判别sItem是否在aList中
    def in_list(self, aList, sItem):
        for tmp in aList:
            if (sItem == tmp):
                return True
        return False

    # 是否是特征词
    def in_region(self,word):
        return word in self.region_words

    def find_duplicate(self):
        aRegion = self.equipment_wds+self.concept_wds+self.work_wds
        ret = []
        for wd in aRegion:
            times = 0
            for tmp in aRegion:
                if wd==tmp:
                    times +=1
            ret.append({'wd':wd, 't':times})
        for wd in ret:
            if(wd.get('t')>1):
                print(wd)
        return ret



if __name__ == '__main__':
    handler = PowerKeywords()
    print(handler.check_keywords('阻波器被短接前，严防等电位作业人员人体短接阻波器。'))
    print(handler.check_keywords(''))
    handler.find_duplicate()
