#!/usr/bin/env python3
# coding: utf-8

import os
import codecs
import jieba
import requests
import random
import time
from lxml import etree
from question_classify import aWord_ALL

OPERATION_TYPE_QUESTION = 'QUESTION'
OPERATION_TYPE_ADD = 'ADD'
OPERATION_TYPE_ADD_FORCE = 'ADD_FORCE'
OPERATION_TYPE_DELETE = 'DELETE'
OPERATION_TYPE_LIST_ANSWER = 'LIST_ANSWER'
OPERATION_TYPE_LIST_QUESTION = 'LIST_QUESTION'
OPERATION_TYPE_NONE = 'NONE'

#解析微信msg中提交的问题+答案
#问题类型关键字 + - * =
#样例：
#@小助教\u2005
#@昵称 \n+问题\n-答案\n换行后继续答
def Prase_Content(sContent, sNikeName):
	#print('Prase_Content:',sContent)
	if (-1 == sContent.find('@'+sNikeName)):
		return (OPERATION_TYPE_NONE, None, None)
	sContent = sContent.replace('@'+sNikeName+'\u2005','')
	aContent = sContent.split('\n')
	#print(type(aContent) ,aContent)
	iLength = len(aContent)
	if(iLength>=2):
		if('+'==aContent[0][0]):
			# +代表提交问题，必须为一行
			sOperation = OPERATION_TYPE_ADD
			sQuestion = aContent[0][1:]
		elif('='==aContent[0][0]):
			# =代表强制提交问题
			sOperation = OPERATION_TYPE_ADD_FORCE
			sQuestion = aContent[0][1:]
		elif ('-' == aContent[0][0]):
			# -代表删除问题库中的问题
			sOperation = OPERATION_TYPE_DELETE
			sQuestion = aContent[0][1:]
		elif ('*' == aContent[0][0]):
			# *代表按关键字提供问题列表
			sOperation = OPERATION_TYPE_LIST_ANSWER
			sQuestion = aContent[0][1:]
		else:
			sOperation = OPERATION_TYPE_QUESTION
			sQuestion = aContent[0]
		aAnswer = []
		# 代表答案，允许换行
		# 属于答案提交模式
		for loc in range(1,iLength):
			aAnswer.append(aContent[loc])
		sAnswer = '\n'.join(aAnswer)
		return (sOperation, sQuestion, sAnswer)
	else:
		# 仅有一行输入
		if ('-' == aContent[0][0]):
			# -代表删除问题库中的问题
			sOperation = OPERATION_TYPE_DELETE
			sQuestion = aContent[0][1:]
		elif ('*' == aContent[0][0]):
			# *代表按关键字提供问题列表
			sOperation = OPERATION_TYPE_LIST_ANSWER
			sQuestion = aContent[0][1:]
		elif ('?' == aContent[0][0]):
			# *代表按关键字提供问题列表
			sOperation = OPERATION_TYPE_LIST_QUESTION
			sQuestion = u'问题列表'
		else:
			sOperation = OPERATION_TYPE_QUESTION
			sQuestion = aContent[0]
		return (sOperation, sQuestion, None)

########## Base Functions ##################
def Save_To_File(filename,text):
	ffile = codecs.open( filename, 'w', 'utf-8')
	ffile.write(text)
	ffile.close()

def Load_From_File(filename):
	ffile = codecs.open( filename, 'r', 'utf-8')
	text = ffile.read()
	ffile.close()
	return text

# 需要启动后执行一次
def Create_userdict(aKeywords):
	print('Create_userdict')
	cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
	userdict_path = os.path.join(cur_dir, 'dict/userdict.txt')
	sText = '\n'.join(aKeywords)
	Save_To_File(userdict_path, sText)

# 需要启动后执行一次
def Init_Jieba():
	print('Init_Jieba')
	cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
	userdict_path = os.path.join(cur_dir, 'dict/userdict.txt')
	jieba.load_userdict(userdict_path)

# 问题的关键词提取，返回List
def Key_Words(sString):
	#print(type(sString),sString)
	seg_list = list(jieba.cut(sString, cut_all=False))
	seg_list = Delete_duplicate(seg_list)
	aWord = Get_New_Words(seg_list)
	return aWord

# 删除重复项
def Delete_duplicate(aList):
	aRet = []
	for sItem in aList:
		if (not In_list(aRet, sItem)):
			aRet.append(sItem)
	return aRet

# 判别sItem是否在aList中
def In_list(aList, sItem):
	for tmp in aList:
		if (sItem == tmp):
			return True
	return False

# 排除wds中出现在aWord_ALL中的词
def Get_New_Words(wds):
	aWord = []
	for wd in wds:
		if wd in aWord_ALL:
			pass
		else:
			if(1<len(wd)):
				aWord.append(wd)
	return aWord

def Baidu_Baike_Declaration(sKeyWord):
	#解析百度百科页面，返回条目的定义项，String
	url = 'https://baike.baidu.com/item/' + sKeyWord
	sHtml = Get_Html_String(url)
	selector = etree.HTML( sHtml )
	sRet = ''
	try:
		articleh = selector.xpath( '//div[@class="para"]' )
		if(articleh):
			aString = articleh[0].xpath('.//text()')
			sRet = ''.join(aString)
	except:
		pass
	return sRet

def Get_Html_String( url ):
	# 返回:页面Html, <type 'unicode'>
	headers = {
		"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36"}
	try:
		response = requests.get( url, headers=headers, timeout=4.3)
	except (IOError) as err:
		time.sleep(random.randint(0.5, 1))
		try:
			response = requests.get(url, headers=headers, timeout=4.3)
		except (IOError) as err:
			#print 'Get_Html_String_Use_Private_Proxy()2 ERROR:', err
			return '<HTML></HTML>'
	response.encoding = 'utf-8'
	return response.text

if __name__ == '__main__':
	Init_Jieba()
	a = Key_Words('@小助教 +如何分享如何问题\n@小助教后输入+，然后输入问题\n换行后输入答案')
	print(a)
	a = Prase_Content('@小助教 +如何分享问题\n@小助教后输入+，然后输入问题，换行后输入答案', '小助教')
	print(a)
	a = Prase_Content('@小助教 +如何分享问题', '小助教')
	print(a)
	a = Key_Words('小助教')
	print(a)
	#a = Key_Words('如何')
	#print(a)
	#print(Baidu_Baike_Declaration('变压器'))