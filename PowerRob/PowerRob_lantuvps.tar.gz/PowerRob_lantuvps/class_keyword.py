# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
import time
import os
import random
# Standard library imports

LIMIT_QUERY = 1000
MAX_KEYWORDS = int(os.environ['MAX_KEYWORDS'])
print('MAX_KEYWORDS:',MAX_KEYWORDS)
###################### Class Define #######################
class Class_Keyword():
	# 处理 Keyword Class的存取

	def Add(self, sKeyword):
		DBClass = leancloud.Object.extend( self.__DBClassName )
		dB = DBClass()
		dB.set('Keyword', sKeyword)
		dB.save()
		return dB.id

	def random_Keyword(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		query.add_descending('updatedAt')  # add_ascending()
		query.skip(random.randint(0,MAX_KEYWORDS))
		oKeyword = query.first()
		if(not oKeyword):
			return ''
		return oKeyword.get('Keyword')

	def Keywords(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		# query.equal_to('Keyword', '')
		#query.does_not_exist('Keyword')
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.add_descending('createdAt')
		page = 0
		aKeyword = []
		while (True):
			print ('Page:', page)
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			Find = query.find()  # 查找descending
			print('Find:', len(Find))
			for oKeyword in Find:
				aKeyword.append(oKeyword.get('Keyword'))
			# print(oKeyword.get('Title'), '\t', sKeyword)
			# time.sleep(1)
			if (len(Find) < LIMIT_QUERY):
				break;
			page = page + 1
		return aKeyword

	def Find_Du(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		# query.equal_to('Keyword', '')
		#query.does_not_exist('Keyword')
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.add_descending('createdAt')
		page = 0
		aKeyword = []
		while (True):
			print ('Page:', page)
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			Find = query.find()  # 查找descending
			print('Find:', len(Find))
			for oKeyword in Find:
				aKeyword.append(oKeyword.get('Keyword'))
			# print(oKeyword.get('Title'), '\t', sKeyword)
			# time.sleep(1)
			if (len(Find) < LIMIT_QUERY):
				break;
			page = page + 1
		ret = []
		for wd in aKeyword:
			times = 0
			for tmp in aKeyword:
				if wd == tmp:
					times += 1
			ret.append({'wd': wd, 't': times})
		for wd in ret:
			if (wd.get('t') > 1):
				print(wd,wd.get('t'))
		return True


	def Update(self):
		DBClass = leancloud.Object.extend( self.__DBClassName )
		query = DBClass.query
		#query.equal_to('Keyword', '')
		query.does_not_exist('Keyword')
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.add_descending('createdAt')
		page = 0
		while (True):
			print ('Page:', page)
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			Find = query.find()  # 查找descending
			print('Find:',len(Find))
			for oKeyword in Find:
				todo = DBClass.create_without_data(oKeyword.get('objectId'))
				sKeyword = oKeyword.get('Title').replace(' ','')
				sKeyword = self.delete_KH(sKeyword)
				todo.set('Keyword', sKeyword)
				todo.save()
				#print(oKeyword.get('Title'), '\t', sKeyword)
				#time.sleep(1)
			if (len(Find) < LIMIT_QUERY):
				break;
			page = page + 1
			#time.sleep(1)
	def delete_KH(self, sString):
		iStart = sString.find( '[' )
		iEnd = sString.find( ']' )
		if (-1 != iStart and -1 != iEnd):
			sDel = sString[iStart:iEnd+1]
			sString = sString.replace(sDel,'')
			return sString
		return sString

	############## private #####
	def __init__(self):
		self.__DBClassName = "Keyword"
		#self.aQuestion = []

##########################Do not delete############################
KEYWORD_CLASS = Class_Keyword()
