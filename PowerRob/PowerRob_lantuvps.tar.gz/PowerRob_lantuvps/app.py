# coding: utf-8

from datetime import datetime
import io

from flask import Flask,Response
from flask_sockets import Sockets

from views.answers import answers_view

app = Flask(__name__)
sockets = Sockets(app)

# 动态路由
app.register_blueprint(answers_view, url_prefix='/answers')


@app.route('/')
def index():
    return '200 OK'


@app.route('/time')
def time():
    return str(datetime.now())

@app.route("/img999")
def image():
    with open("QR.png", 'rb') as f:
        image = f.read()
    #image = file.open("QR.png")
    resp = Response(image, mimetype="image/png")
    #return send_file(io.BytesIO(image.read()), attachment_filename='QR.png', mimetype='image/png')
    return resp


@sockets.route('/echo')
def echo_socket(ws):
    while True:
        message = ws.receive()
        ws.send(message)
