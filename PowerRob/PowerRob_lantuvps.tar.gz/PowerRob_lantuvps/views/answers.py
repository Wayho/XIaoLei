# coding: utf-8

from leancloud import Object
from leancloud import Query
from leancloud import LeanCloudError
from flask import Blueprint
from flask import request
from flask import redirect
from flask import url_for
from flask import render_template

from question_classify import Classify

class Answer(Object):
    pass

answers_view = Blueprint('answers', __name__)


@answers_view.route('')
def show():
    try:
        answers = Query(Answer).descending('createdAt').find()
    except LeanCloudError as e:
        if e.code == 101:  # 服务端对应的 Class 还没创建
            answers = []
        else:
            raise e
    return render_template('answers.html', answers=answers)


@answers_view.route('', methods=['POST'])
def add():
    sQuestion = request.form['Question']
    sAnswer = request.form['Answer']
    answer = Answer(Question=sQuestion, Answer=sAnswer)
    try:
        answer.set('Type', Classify(sQuestion))
        answer.set('From', '网络')
        answer.save()
    except LeanCloudError as e:
        return e.error, 502
    return redirect(url_for('answers.show'))
