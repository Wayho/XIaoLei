#!/usr/bin/env python3
# coding: utf-8

# 特征词出现的次数
class SearchKeywords:
    def __init__(self,sDest, aWords):
        self.sDest = sDest
        self.aWords = aWords
        return

    # 返回特征词组在self.sDest中出现的次数
    def hit_times(self):
        times = 0
        for word in self.aWords:
            times += self.hit(word)
        return times

    # 特征词在self.sDest中返回1,否则返回0
    def hit(self, word):
        if(-1==self.sDest.find(word)):
            return 0
        else:
            return 1

if __name__ == '__main__':
    answer = '断路器|开关|合闸|位置|跳闸|回路|熔断器|保险|短接'
    #words = {'断路器','电流','电压'}
    words = {}
    print(words)
    handler = SearchKeywords(answer,words)
    #print(handler.find_duplicate())
    print(handler.hit_times())
