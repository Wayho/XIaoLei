# coding: utf-8

import os
import time
from leancloud import Engine
from leancloud import LeanEngineError
import random

from yml import YmlFile
from class_answer import ANSWER_CLASS
from class_question import QUESTION_CLASS
from class_chatroom import Class_Chatroom

import itchat
from itchat.content import *

from utils import *
from question_classify import Classify,QUESTION_TYPE_WHAT, QUESTION_TYPE_NONE
from power_keywords import PowerKeywords
from class_keyword import KEYWORD_CLASS
POWER_KEY_WORDS = PowerKeywords()

engine = Engine()

APP_ROOT = os.environ.get('LEANCLOUD_APP_REPO_PATH')
APP_DOMAIN = os.environ.get('LEANCLOUD_APP_DOMAIN')
ROBOT_NAME = os.environ.get('ROBOT_NAME')			#所有人@

if (not ROBOT_NAME):
	ROBOT_NAME = '小助教'
CHATROOMS = []

print('ROBOT_NAME:',ROBOT_NAME)
print('APP_ROOT:',APP_ROOT)
print( 'APP_DOMAIN:',APP_DOMAIN)

ENGINE_RESTART = False
DEBUG = False



@engine.define( 'update' )
def update():
	aKeywords = KEYWORD_CLASS.Keywords()
	adict = POWER_KEY_WORDS.userdict_wds
	for sDict in adict:
		if(not In_list(aKeywords,sDict)):
			print(sDict)
			#KEYWORD_CLASS.Add(sDict)

@engine.define( 'debug' )
def debug():
	global DEBUG
	DEBUG = True
	print('DEBUG:',DEBUG)
	return DEBUG

@engine.define( 'nodebug' )
def nodebug():
	global DEBUG
	DEBUG = False
	print('DEBUG:', DEBUG)
	return DEBUG

@engine.define( 'alert' )
def Alert():
	if (itchat.is_running):
		frnd = random.random()
		sMsg = ''
		if(frnd > 0.3):
			sKeyword = KEYWORD_CLASS.random_Keyword()
			sMsg = Baidu_Baike_Declaration(sKeyword)
			if( sMsg ):
				sMsg = '【{0}】\n{1}'.format(sKeyword, sMsg)
			else:
				sMsg = ANSWER_CLASS.random_answer()
		else:
			sMsg = ANSWER_CLASS.random_answer()
		for oRoom in CHATROOMS:
			if (oRoom.get('Alert')):
				if (sMsg):
					itchat.send(sMsg, oRoom.get('UserName'))
		return sMsg[:30]
	else:
		return 'itchat is not running'


###############################################
# 必须设法在重启后运行该函数
# 15 */5 7-23  * * ?
@engine.define( 'auto_run' )
def auto_run():
	global CHATROOMS
	if(0):
		return 'itchat is running'
	else:
		if (0):
			return 'itchat is logging'
		else:
			itchat.auto_login(enableCmdQR=2, hotReload=True, loginCallback=lc, exitCallback=ec)
		time.sleep(0.1)
		aKeywords = KEYWORD_CLASS.Keywords()
		Create_userdict(aKeywords)
		Init_Jieba()
		init_CHATROOMS()
		print(CHATROOMS)
		itchat.run()
		return 'itchat is over'

def init_CHATROOMS():
	global CHATROOMS
	if (itchat.is_running()):
		oChatroom = Class_Chatroom()
		aChatrooms = oChatroom.chatroom()
		chatrooms = itchat.get_chatrooms(update=True, contactOnly=False)
		CHATROOMS = []
		for item in chatrooms:
			for oRoom in aChatrooms:
				if (item.get('NickName') == oRoom.get('NickName')):
					CHATROOMS.append({'UserName': item.get('UserName'), 'NickName': item.get('NickName'), 'Alert':oRoom.get('Alert')})
		return CHATROOMS
	else:
		return 'itchat is not running'

def lc():
	print('itchat finish login')
def ec():
	print('itchat exit')

def get_chatroom_UserName(sChatroom_NickName):
	for oRoom in CHATROOMS:
		if(oRoom.get('NickName')==sChatroom_NickName):
			return oRoom.get('UserName')
	return None

# 在注册时增加isGroupChat=True将判定为群聊回复
@itchat.msg_register(TEXT, isGroupChat = True)
def groupchat_reply(msg):
	if(DEBUG):
		print(msg)
	#print(msg.get('User').get('NickName'))
	sChatroom_NickName = msg.get('User').get('NickName')
	sChatroom_UserName = get_chatroom_UserName(sChatroom_NickName)
	if( sChatroom_UserName):
		sActualNickName = msg.get('ActualNickName')
		if(sActualNickName==ROBOT_NAME):
			sFromUserName = sChatroom_UserName
		else:
			sFromUserName = msg.get('FromUserName')
		print('from:', sChatroom_NickName, sActualNickName, msg.get('Content')[:30]) ## 发送者的昵称
		if( msg.get('isAt')):
			(sOperation, sQuestion, sAnswer) = Prase_Content(msg.get('Content'), ROBOT_NAME )
			aKey_Words = Key_Words(sQuestion)
			sType = Classify(sQuestion)

			if(0==len(aKey_Words) and OPERATION_TYPE_LIST_QUESTION != sOperation):
				return

			print(sOperation, sType, aKey_Words)

			if (OPERATION_TYPE_QUESTION == sOperation):
				if (sQuestion):
					if (1 == len(aKey_Words) or QUESTION_TYPE_WHAT == sType or QUESTION_TYPE_NONE == sType):
						# 首选百度定义
						sWord = ''.join(aKey_Words)
						sMsg = Baidu_Baike_Declaration(sWord)
						if (sMsg):
							if (sActualNickName != ROBOT_NAME):
								sMsg = u'@{0}\u2005{1}\n来源：百度'.format(sActualNickName, sMsg)
							# itchat.send(u'@{0}\u2005{1}\n来源：百度'.format(sActualNickName, sMsg), sFromUserName)
							else:
								sMsg = u'{0}\n来源：百度'.format(sMsg)
							itchat.send(sMsg, sFromUserName)
							return
					sMsg = ANSWER_CLASS.best_answer(sType, aKey_Words)
					if (sMsg):
						if (sActualNickName != ROBOT_NAME):
							sMsg = u'@{0}\u2005{1}'.format(sActualNickName, sMsg)
							#itchat.send(u'@{0}\u2005{1}'.format(sActualNickName, sMsg), sFromUserName)
						itchat.send(sMsg, sFromUserName)
					else:
						oQuestion = {'From':sActualNickName, 'Question':sQuestion}
						QUESTION_CLASS.Add(oQuestion)
						if (sActualNickName != ROBOT_NAME):
							sMsg = u'@{0}\u2005抱歉，我不知道，已把您的问题记录在案，如果谁知道答案，请记得来教我。'.format(sActualNickName)
						else:
							sMsg = u'抱歉，我不知道，已把您的问题记录在案，如果谁知道答案，请记得来教我。'
						itchat.send(sMsg, sFromUserName)
				else:
					pass
			elif( OPERATION_TYPE_ADD == sOperation ):
				if (1 == len(aKey_Words) and sType == QUESTION_TYPE_NONE):
					sType = QUESTION_TYPE_WHAT
				oAnswer = {'From':sActualNickName, 'Type':sType, 'Question':sQuestion, 'Answer':sAnswer}
				sMsg = ANSWER_CLASS.Add_Answer(oAnswer)
				if(sMsg):
					if (sActualNickName != ROBOT_NAME):
						sMsg = u'@{0}\u2005知识已在库中：\n{1}\n\n若坚持要入库，请使用把+改为=重新提交！'.format(sActualNickName, sMsg)
					else:
						sMsg = u'知识已在库中：\n{0}\n\n若坚持要入库，请使用把+改为=重新提交！'.format(sMsg)
					itchat.send(sMsg, sFromUserName)
				else:
					QUESTION_CLASS.Delete(sQuestion)
					if (sActualNickName != ROBOT_NAME):
						sMsg = u'@{0}\u2005您贡献的知识：\n{1}\n\n已收入库中，感谢分享！'.format(sActualNickName, sQuestion)
					else:
						sMsg = u'您贡献的知识：\n{0}\n\n已收入库中，感谢分享！'.format(sQuestion)
					itchat.send(sMsg, sFromUserName)
			elif(OPERATION_TYPE_ADD_FORCE == sOperation):
				oAnswer = {'From': sActualNickName, 'Type': sType, 'Question': sQuestion, 'Answer': sAnswer}
				objectId = ANSWER_CLASS.Do_Add_Answer(oAnswer)
				if (objectId):
					QUESTION_CLASS.Delete(sQuestion)
					if (sActualNickName != ROBOT_NAME):
						sMsg = u'@{0}\u2005您贡献的知识：\n{1}\n\n已收入库中，感谢分享！'.format(sActualNickName, sQuestion)
					else:
						sMsg = u'您贡献的知识：\n{0}\n\n已收入库中，感谢分享！'.format(sQuestion)
					itchat.send(sMsg, sFromUserName)
			elif(OPERATION_TYPE_DELETE == sOperation):
				QUESTION_CLASS.Delete(sQuestion)
				if (sActualNickName != ROBOT_NAME):
					sMsg = u'@{0}\u2005您申请删除的问题：\n{1}\n已删除，谢谢！'.format(sActualNickName, sQuestion)
				else:
					sMsg = u'您申请删除的问题：\n{0}\n已删除，谢谢！'.format(sQuestion)
				itchat.send(sMsg, sFromUserName)
			elif(OPERATION_TYPE_LIST_ANSWER == sOperation):
				pass
			elif (OPERATION_TYPE_LIST_QUESTION == sOperation):
				sMsg = QUESTION_CLASS.All10()
				if (sActualNickName != ROBOT_NAME):
					sMsg = u'@{0}\u2005{1}'.format(sActualNickName, sMsg)
				itchat.send(sMsg, sFromUserName)

auto_run()
