#!/usr/bin/env python3
# coding: utf-8

QUESTION_TYPE_WHAT = 'WHT'
QUESTION_TYPE_WHY = 'WHY'
QUESTION_TYPE_HOW = 'HOW'
QUESTION_TYPE_USE = 'USE'
QUESTION_TYPE_NONE = 'NON'

aWord_WHY = ['原因','成因', '原理', '工作原理', '原理工作', '为什么', '怎么会', '怎样才', '咋样才', '怎样会', '如何会', '为啥', '为何', '如何才会', '怎么才会', '会导致', '会造成']
aWord_HOW = ['如何', '怎样', '怎样才能', '咋样才能', '怎么', '怎么才', '什么方法', '怎么办', '方法', '的办法', '办法']
aWord_USE = ['作用', '作用是什么', '起什么作用', '有什么作用', '有什么用', '用途', '有什么危害', '有什么危险', '有何危害', '有何危险', '意义', '有什么影响','有何影响', '功效',  '功能',  '效用', '产生什么后果', '产生何后果']
aWord_WHAT = ['什么', '是什么', '何谓', '是什么呢', '是什么东西', '是什么东东', '是怎么回事', '什么是', '什么叫', '的定义', '定义', '的概念', '概念']
aWord_ASK = ['请问', '请教']
aWord_ALL = aWord_WHY + aWord_HOW + aWord_WHAT + aWord_USE + aWord_ASK

'''分类主函数'''
def Classify(sQuestion):
    if (Check_Words(sQuestion, aWord_WHY)):
        return QUESTION_TYPE_WHY
    if( Check_Words(sQuestion,aWord_HOW)):
        return QUESTION_TYPE_HOW
    if (Check_Words(sQuestion, aWord_USE)):
        return QUESTION_TYPE_USE
    if (Check_Words(sQuestion, aWord_WHAT)):
        return QUESTION_TYPE_WHAT
    return QUESTION_TYPE_NONE

# 特征词在sQuestion中否
def Check_Words( sQuestion, aWords):
    for wd in aWords:
        if(sQuestion.find(wd)!=-1):
            return True
    return False


if __name__ == '__main__':
    sQuestion = '@小助教 +如何分享问题和答案\n-@教学助手后输入+\n然后输入问题\n换行后输入-\n然后输入答案'
    ret = Classify(sQuestion)
    print(sQuestion,ret)