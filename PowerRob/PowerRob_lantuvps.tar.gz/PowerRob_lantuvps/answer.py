#!/usr/bin/env python3
# coding: utf-8

from yml import YmlFile
from search_keywords import SearchKeywords

# 直接使用YmlFile来搜索答案
class Answer:
    def __init__(self):
        self.yml = YmlFile()
        return

    # 返回特征词组在self.yml.answer中命中最多的oAnswer
    def best_answer(self, aWords):
        print(aWords)
        max_hit = 0
        aOffset = []
        for tmp in self.yml.answer:
            handler = SearchKeywords(tmp.get('Region')+tmp.get('Answer'), aWords)
            hit = handler.hit_times()
            if (hit > max_hit):
                max_hit = hit
        if (0 == max_hit):
            return []
        for tmp in self.yml.answer:
            handler = SearchKeywords(tmp.get('Region')+tmp.get('Answer'), aWords)
            hit = handler.hit_times()
            if (hit == max_hit):
                aOffset.append(tmp.get('Offset'))

        print(max_hit, aOffset)
        aAnswer = []
        for offset in aOffset:
            aAnswer.append(self.yml.answer[offset].get('Answer'))
            print(offset, self.yml.answer[offset].get('Answer')[:30])
        return aAnswer

    def print_self(self):
        for answer in self.yml.answer:
            print(answer)


if __name__ == '__main__':
    handler = Answer()
    handler.print_self()
    best = handler.best_answer({'带电短接设备'})#,'断路器'})
    print(best)

