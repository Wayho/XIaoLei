# coding: utf-8
import leancloud							#requirements leancloud-sdk>=1.0.9,<=2.0.0
import random
# Standard library imports
from search_keywords import SearchKeywords
from question_classify import QUESTION_TYPE_NONE, QUESTION_TYPE_HOW, QUESTION_TYPE_WHY, QUESTION_TYPE_USE

LIMIT_QUERY = 3
MAX_ITEMS = 1216
###################### Class Define #######################
class Class_Answer():
	# 处理 Answer Class的存取，属性aKeywords

	def random_answer(self):
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		query.add_descending('updatedAt')  # add_ascending()
		query.skip(random.randint(0,MAX_ITEMS))
		oAnswer = query.first()
		if(not oAnswer):
			return ''
		return '【{0}】\n{1}\n来源：{2}'.format(oAnswer.get('Question'), oAnswer.get('Answer'), oAnswer.get('From'))

	# sType必须为QUESTION_TYPE_XXX
	def best_answer1(self, sType, aKeyWords):
		if (1 > len(aKeyWords)):
			return {}
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query1 = DBClass.query
		query1.add_descending('updatedAt')  # add_ascending()
		#query1.select('Type', 'From', 'Question', 'Answer')
		if(QUESTION_TYPE_HOW==sType or QUESTION_TYPE_WHY==sType or QUESTION_TYPE_USE==sType):
			query1.equal_to('Type', sType)
		query1.contains('Question', aKeyWords[0])
		try:
			oAnswer = query1.first()
			return {'From': oAnswer.get('From'), 'Question': oAnswer.get('Question'), 'Answer': oAnswer.get('Answer')}
		except:
			return {}

	def best_answer2(self, sType, aKeyWords):
		if (2 > len(aKeyWords)):
			return {}
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query1 = DBClass.query
		query2 = DBClass.query
		if(QUESTION_TYPE_NONE!=sType):
			query1.equal_to('Type', sType)
			query2.equal_to('Type', sType)
		query1.contains('Question', aKeyWords[0])
		query2.contains('Question', aKeyWords[1])
		query = leancloud.Query.and_(query1, query2)
		query.add_descending('updatedAt')
		try:
			oAnswer = query.first()
			return {'From':oAnswer.get('From'), 'Question':oAnswer.get('Question'), 'Answer':oAnswer.get('Answer')}
		except:
			return {}

	def best_answer3(self, sType, aKeyWords):
		if (3 > len(aKeyWords)):
			return {}
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query1 = DBClass.query
		query2 = DBClass.query
		query3 = DBClass.query
		if(QUESTION_TYPE_NONE!=sType):
			query1.equal_to('Type', sType)
			query2.equal_to('Type', sType)
			query3.equal_to('Type', sType)
		query1.contains('Question', aKeyWords[0])
		query2.contains('Question', aKeyWords[1])
		query3.contains('Question', aKeyWords[2])
		query = leancloud.Query.and_(query1, query2, query3)
		query.add_descending('updatedAt')
		try:
			oAnswer = query.first()
			return {'From': oAnswer.get('From'), 'Question': oAnswer.get('Question'), 'Answer': oAnswer.get('Answer')}
		except:
			return {}

	def best_answer4(self, sType, aKeyWords):
		if (4 > len(aKeyWords)):
			return {}
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query1 = DBClass.query
		query2 = DBClass.query
		query3 = DBClass.query
		query4 = DBClass.query
		if(QUESTION_TYPE_NONE!=sType):
			query1.equal_to('Type', sType)
			query2.equal_to('Type', sType)
			query3.equal_to('Type', sType)
			query4.equal_to('Type', sType)
		query1.contains('Question', aKeyWords[0])
		query2.contains('Question', aKeyWords[1])
		query3.contains('Question', aKeyWords[2])
		query4.contains('Question', aKeyWords[3])
		query = leancloud.Query.and_(query1, query2, query3, query4)
		query.add_descending('updatedAt')
		try:
			oAnswer = query.first()
			return {'From': oAnswer.get('From'), 'Question': oAnswer.get('Question'), 'Answer': oAnswer.get('Answer')}
		except:
			return {}

	def best_answer(self, sType, aKeyWords):
		#aKeyWords = list(set(aKeyWords))
		length = len(aKeyWords)
		oAnswer ={}
		if(0==length):
			return ''
		elif(1==length):
			oAnswer = self.best_answer1(sType, aKeyWords)
		elif(2==length):
			oAnswer = self.best_answer2(sType, aKeyWords)
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, aKeyWords)
		elif(3==length):
			oAnswer = self.best_answer3(sType, aKeyWords)
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[1]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[2]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[1], aKeyWords[2]])
		elif (4 <= length):
			oAnswer = self.best_answer4(sType, aKeyWords)
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer3(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[1], aKeyWords[2]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer3(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[1], aKeyWords[3]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer3(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[2], aKeyWords[3]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer3(QUESTION_TYPE_NONE, [aKeyWords[1], aKeyWords[2], aKeyWords[3]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[1]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[2]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[0], aKeyWords[3]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[1], aKeyWords[2]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[1], aKeyWords[3]])
			if (0 == len(oAnswer)):
				oAnswer = self.best_answer2(QUESTION_TYPE_NONE, [aKeyWords[2], aKeyWords[3]])
		if(0==len(oAnswer)):
			return ''
		#sMsg = oAnswer.get('Question') + '\n' + oAnswer.get('Answer') + '\n来源：' + oAnswer.get('From')
		return '【{0}】\n{1}\n来源：{2}'.format(oAnswer.get('Question'), oAnswer.get('Answer'), oAnswer.get('From'))

	# 返回特征词组在self.aKeywords中命中最多的oAnswer
	def best_answer_by_keywords(self, aWords):
		print(aWords)
		max_hit = 0
		aObjectId = []
		for tmp in self.aKeywords:
			handler = SearchKeywords(tmp.get('Keywords'), aWords)
			hit = handler.hit_times()
			if(hit > max_hit):
				max_hit = hit
		if(0==max_hit):
			return []
		for tmp in self.aKeywords:
			handler = SearchKeywords(tmp.get('Keywords'), aWords)
			hit = handler.hit_times()
			if(hit == max_hit):
				aObjectId.append(tmp.get('objectId'))

		print(max_hit,aObjectId)
		aAnswer = []
		for objectId in aObjectId:
			#print(self.Get(objectId).get('objectId'))
			aAnswer.append(self.Get(objectId).get('Answer'))
		return aAnswer

	def Add_Answer(self, oAnswer):
		# 检查存过没有，若有，返回Msg，否则Add后返回None
		DBClass = leancloud.Object.extend( self.__DBClassName )
		query = DBClass.query
		query.equal_to('Question', oAnswer.get('Question'))
		try:
			oAnswer = query.first()
			return '【{0}】\n{1}\n来源：{2}'.format(oAnswer.get('Question'), oAnswer.get('Answer'), oAnswer.get('From'))
		except:
			objectId = self.Do_Add_Answer(oAnswer)
			if(not objectId):
				self.Do_Add_Answer(oAnswer)
			return None


	def Do_Add_Answer(self, oAnswer):
		# 返回 None
		# 检查存过没有
		DBClass = leancloud.Object.extend( self.__DBClassName )
		dB = DBClass()
		dB.set('Type', oAnswer.get('Type') )
		dB.set('From', oAnswer.get('From'))
		dB.set('Question', oAnswer.get('Question'))
		dB.set('Answer', oAnswer.get('Answer'))
		#dB.set('Length', len(oAnswer.get('Answer')))
		dB.save()
		return dB.id

	def Update_Keywords(self, objectId, sKeywords):
		# 保存到 XXXX_Class
		# 返回 objectId
		DBClass = leancloud.Object.extend( self.__DBClassName )
		if(objectId is not None):
			dB = DBClass.create_without_data( objectId )
			dB.set('Keywords', sKeywords)  # update
			dB.save( )
		return objectId


	def Init_Answer_All(self):
		print('Init_Answer_All')
		DBClass = leancloud.Object.extend(self.__DBClassName)
		query = DBClass.query
		query.limit(LIMIT_QUERY)  # 最多返回 LIMIT_QUERY 条结果
		query.add_ascending('Type')  # descending()
		query.select('objectId','Type', 'From', 'Question', 'Answer')
		page = 0
		self.aAnswer = []
		while (True):
			print('Page:', page)
			query.skip(page * LIMIT_QUERY)  # 跳过 page*LIMIT_QUERY 条结果
			aFind = query.find()  # 查找descending
			for item in aFind:
				self.aAnswer.append(
					{'objectId': item.get('objectId'), 'Type': item.get('Type'), 'From': item.get('From'), 'Question': item.get('Question'), 'Answer': item.get('Answer')})
			if (len(aFind) < LIMIT_QUERY):
				break
			page = page + 1
			#time.sleep(0.2)


	############## private #####
	def __init__(self):
		self.__DBClassName = "Answer"
		self.aKeywords = []
		#self.Init_Keywords_All()


##########################Do not delete############################
ANSWER_CLASS = Class_Answer()
